#include <exception>
#include <string>
#include <iostream>
#include <SDL2/SDL.h>


#include <SDL2/SDL_opengles2.h>
#include <GLES3/gl3.h>
#include <cstdio>
#include <cstdlib>
#include "irrlicht.h"
#include "CVertexBuffer.h"

#include "Utils.h"
#include "Core.h"
#include "CColorConverter.h"

using namespace irr;
using namespace scene;
using namespace video;



const unsigned int DISP_WIDTH = 1025;
const unsigned int DISP_HEIGHT = 720;
const char* TITLE=" Stencil test Batch";
SDL_Window *window = NULL;
SDL_GLContext context = NULL;
const Uint8 *state=NULL;
Uint32 mouse_buttons;
int mouse_x;
int mouse_y;

irr::scene::Engine* engine;
int width, height;
float aspect;
core::matrix4 pMat, vMat, mMat;

// camera
core::vector3df cameraPos   = core::vector3df(0.0f, 2.0f, 5.0f);
core::vector3df cameraFront = core::vector3df(0.0f, 0.0f, -1.0f);
core::vector3df cameraUp    = core::vector3df(0.0f, 1.0f, 0.0f);

bool firstMouse = true;
bool isMouseDown = false;
float yaw   = -90.0f;	// yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right so we initially rotate a bit to the left.
float pitch =  0.0f;
float lastX =  800.0f / 2.0;
float lastY =  600.0 / 2.0;
float fov   =  45.0f;



class Tex2d
{
public:
  Tex2d(){};

  void Load(const char* fileName)
  {

        texture = engine->getTexture("media/font.png");



             		  // Create and compile the vertex shader
		const char* vertexShaderSource = GLSL(

					// Input vertex data, different for all executions of this shader.
					attribute vec2 vertexPosition_screenspace;
					attribute vec2 vertexUV;

					// Output data ; will be interpolated for each fragment.
					varying vec2 UV;

					void main(){


						vec2 vertexPosition_homoneneousspace = vertexPosition_screenspace - vec2(400,300);
						vertexPosition_homoneneousspace /= vec2(400,300);
						//gl_Position =  vec4(vertexPosition_screenspace,0,1);
						gl_Position =  vec4(vertexPosition_homoneneousspace,0,1);

						// UV of the vertex. No special space for this one.
						UV = vertexUV;
					}
			);

		const char *fragmentShaderSource = GLSL(
                precision highp float;
				varying vec2 UV;
				uniform sampler2D tex;

				void main(){

                    gl_FragColor = texture2D( tex, UV );


				}


		);

		  shader.FromString(vertexShaderSource,fragmentShaderSource);
		  shader.Use();
		  shader.setInt("tex", 0);
          glGenBuffers(1, &Text2DVertexBufferID);
		  glGenBuffers(1, &Text2DUVBufferID);



	glGenBuffers(1, &Text2DVertexBufferID);
	glGenBuffers(1, &Text2DUVBufferID);



  }
  void Print(const char * text, float x, float y, float size)
  {
	// Bind shader
	shader.Use();
	//engine->setShader(&shader);

	// Bind texture




   	//engine->setTexture(GL_TEXTURE_2D,texture.ID);
   	engine->setTexture(texture);


     unsigned int length = strlen(text);

	// Fill buffers
	std::vector<core::vector2df> vertices;
	std::vector<core::vector2df> UVs;
	for ( unsigned int i=0 ; i<length ; i++ ){

		core::vector2df vertex_up_left    = core::vector2df( x+i*size     , y+size );
		core::vector2df vertex_up_right   = core::vector2df( x+i*size+size, y+size );
		core::vector2df vertex_down_right = core::vector2df( x+i*size+size, y      );
		core::vector2df vertex_down_left  = core::vector2df( x+i*size     , y      );

		vertices.push_back(vertex_up_left   );
		vertices.push_back(vertex_down_left );
		vertices.push_back(vertex_up_right  );

		vertices.push_back(vertex_down_right);
		vertices.push_back(vertex_up_right);
		vertices.push_back(vertex_down_left);

		char character = text[i];
		float uv_x = (character%16)/16.0f;
		float uv_y = (character/16)/16.0f;

		core::vector2df uv_up_left    = core::vector2df( uv_x           , uv_y );
		core::vector2df uv_up_right   = core::vector2df( uv_x+1.0f/16.0f, uv_y );
		core::vector2df uv_down_right = core::vector2df( uv_x+1.0f/16.0f, (uv_y + 1.0f/16.0f) );
		core::vector2df uv_down_left  = core::vector2df( uv_x           , (uv_y + 1.0f/16.0f) );

		UVs.push_back(uv_up_left   );
		UVs.push_back(uv_down_left );
		UVs.push_back(uv_up_right  );

		UVs.push_back(uv_down_right);
		UVs.push_back(uv_up_right);
		UVs.push_back(uv_down_left);
	}
	glBindBuffer(GL_ARRAY_BUFFER, Text2DVertexBufferID);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(core::vector2df), &vertices[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, Text2DUVBufferID);
	glBufferData(GL_ARRAY_BUFFER, UVs.size() * sizeof(core::vector2df), &UVs[0], GL_STATIC_DRAW);




	// 1rst attribute buffer : vertices
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, Text2DVertexBufferID);
	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, (void*)0 );

	// 2nd attribute buffer : UVs
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, Text2DUVBufferID);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, (void*)0 );

	engine->setBlend(true);
	engine->setBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);




	// Draw call
	glDrawArrays(GL_TRIANGLES, 0, vertices.size() );

	engine->setBlend(false);

	///glDisableVertexAttribArray(0);
	//glDisableVertexAttribArray(1);



  }
  void Unload()
  {
	// Delete buffers
	glDeleteBuffers(1, &Text2DVertexBufferID);
	glDeleteBuffers(1, &Text2DUVBufferID);


  }

 private:
 IShader shader;
 video::ITexture* texture;
unsigned int Text2DVertexBufferID;
unsigned int Text2DUVBufferID;




};


void processInput()
{

    float cameraSpeed = 2.5 * engine->GetFrameTime();
    if (state[SDL_SCANCODE_W])
    {
    cameraPos += cameraSpeed * cameraFront;
    }

    if (state[SDL_SCANCODE_S])
    {
     cameraPos -= cameraSpeed * cameraFront;
    }

    if (state[SDL_SCANCODE_A])
    {
    core::vector3df n = cameraFront.crossProduct(cameraUp).normalize();

    cameraPos -= n * cameraSpeed;
    }

    if (state[SDL_SCANCODE_D])
    {
      core::vector3df n = cameraFront.crossProduct(cameraUp).normalize();
      cameraPos += n * cameraSpeed;
    }



}

void window_size_callback(int newWidth, int newHeight) {
	aspect = (float)newWidth / (float)newHeight;
    glViewport(0, 0, newWidth, newHeight);
    glScissor(0, 0, newWidth, newHeight);
    pMat.buildProjectionMatrixPerspectiveFovRH(core::degToRad(fov),aspect, 0.1f, 1000.0f);
	//pMat = glm::perspective(glm::radians(fov), aspect, 0.1f, 1000.0f);
}
void mouse_callback( double xpos, double ypos)
{
	if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top
    lastX = xpos;
    lastY = ypos;

    float sensitivity = 0.1f; // change this value to your liking
    xoffset *= sensitivity;
    yoffset *= sensitivity;


    if ((mouse_buttons & SDL_BUTTON_RMASK) != 0)
    {

    yaw += xoffset;
	pitch += yoffset;
    }



    // make sure that when pitch is out of bounds, screen doesn't get flipped
    if (pitch > 89.0f)
        pitch = 89.0f;
	if (pitch < -89.0f)
        pitch = -89.0f;

	core::vector3df  front;


	front.X = cos(core::degToRad(yaw)) * cos(core::degToRad(pitch));
	front.Y = sin(core::degToRad(pitch));
	front.Z = sin(core::degToRad(yaw)) * cos(core::degToRad(pitch));
	cameraFront = front.normalize();

}

typedef struct Vertex_s
{
 float x;
 float y;
 float z;
 unsigned char r;
 unsigned char g;
 unsigned char b;
} Vertex;




std::vector<Vertex> vertices;

void rVertex(float x, float y, float z)
{

}

 void DrawGrid(int slices, float spacing)
{
    int halfSlices = slices / 2;


        for(int i = -halfSlices; i <= halfSlices; i++)
        {

            vertices.push_back( { (float)i*spacing, 0.0f, (float)-halfSlices*spacing ,255,255,255 } );
            vertices.push_back( { (float)i*spacing, 0.0f, (float)halfSlices*spacing  ,255,255,255 } );
            vertices.push_back( { (float)-halfSlices*spacing, 0.0f, (float)i*spacing ,255,255,255 } );
            vertices.push_back( { (float)halfSlices*spacing, 0.0f, (float)i*spacing  ,255,255,255 } );
        }

}




int Init()
{
if (SDL_Init(SDL_INIT_VIDEO) < 0)
{
 SDL_Log("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
 return 1;
}

// Request OpenGL ES 3.0

    if(SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES)!=0)
    {
        std::cout << "ERROR loading context profile mask\n";
    }
    if(SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3)!=0)
    {
        std::cout <<"ERROR setting context major version\n";
    }
    if(SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0)!=0)
    {
        std::cout <<"ERROR setting context minor version\n";
    }
    if(SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1) != 0){
        std::cout << " ERrror \n setting double buffer";
    } // I have tried without the dubble buffer and nothing changes
    if(SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE   , 24) != 0){
        std::cout << " ERrror \n setting depth buffer";
    }
    if(SDL_GL_SetAttribute(SDL_GL_BUFFER_SIZE, 32)!=0){
        std::cout << "error setting buffer size\n";
    }
    if(SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8)!=0){
        std::cout << " error loading red\n";
    }
    if(SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8)!=0){
        std::cout << " error loading red\n";
    }if(SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8)!=0){
        std::cout << " error loading red\n";
    }if(SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 8)!=0){
        std::cout <<" Error setting alpha\n";
    }

   if(SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8) != 0){
        std::cout << " ERrror \n setting stencil buffer";
    }

SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);





window = SDL_CreateWindow(TITLE, SDL_WINDOWPOS_UNDEFINED,SDL_WINDOWPOS_UNDEFINED, DISP_WIDTH, DISP_HEIGHT,  SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
if (!window)
{
    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Error","Couldn't create the main window.", NULL);
return 1;
}
context = SDL_GL_CreateContext(window);
if (!context)
{
    SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Error","Couldn't create an OpenGL context.", NULL);
return 1;
}
SDL_GL_SetSwapInterval(0); // Enable vsync




return 0;

}

void Close()
{



    SDL_GL_DeleteContext(context);
    SDL_DestroyWindow(window);
    SDL_Quit();

}


void createlLightTextureShader()
{



const char* vertexSource = GLSL(

attribute vec3 inVertexPosition;
attribute vec3 inVertexNormal;
attribute vec4 inVertexColor;
attribute vec2 inTexCoord0;



uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

varying vec2 varTextureCoord0;
varying vec4 varVertexColor;
varying  vec3 vLighting;


mat3 transpose(mat3 matrix)
{
    vec3 row0 = matrix[0];
    vec3 row1 = matrix[1];
    vec3 row2 = matrix[2];
    mat3 result = mat3(
        vec3(row0.x, row1.x, row2.x),
        vec3(row0.y, row1.y, row2.y),
        vec3(row0.z, row1.z, row2.z)
    );
    return result;
}

float det(mat2 matrix)
{
    return matrix[0].x * matrix[1].y - matrix[0].y * matrix[1].x;
}

mat3 inverse(mat3 matrix) {
    vec3 row0 = matrix[0];
    vec3 row1 = matrix[1];
    vec3 row2 = matrix[2];

    vec3 minors0 = vec3(
        det(mat2(row1.y, row1.z, row2.y, row2.z)),
        det(mat2(row1.z, row1.x, row2.z, row2.x)),
        det(mat2(row1.x, row1.y, row2.x, row2.y))
    );
    vec3 minors1 = vec3(
        det(mat2(row2.y, row2.z, row0.y, row0.z)),
        det(mat2(row2.z, row2.x, row0.z, row0.x)),
        det(mat2(row2.x, row2.y, row0.x, row0.y))
    );
    vec3 minors2 = vec3(
        det(mat2(row0.y, row0.z, row1.y, row1.z)),
        det(mat2(row0.z, row0.x, row1.z, row1.x)),
        det(mat2(row0.x, row0.y, row1.x, row1.y))
    );

    mat3 adj = transpose(mat3(minors0, minors1, minors2));

    return (1.0 / dot(row0, minors0)) * adj;
}

void main()
{

	varTextureCoord0 = inTexCoord0;
	varVertexColor   = inVertexColor;

gl_Position = projection * view * model *   vec4(inVertexPosition,1.0);


       vec3 ambientLight = vec3(1.0, 1.0, 1.0);
       vec3 directionalLightColor = vec3(1, 1, 1);
       //vec3 directionalVector = normalize(vec3(0, -1, 0.75));//vec3(0.85, 0.8, 0.75));
       vec3 directionalVector = normalize(vec3(0.85, 0.8, 0.75));

       mat4 normalMatrix = view * model;

       vec3  uNormalMatrix = mat3(transpose(inverse(mat3(normalMatrix)))) * inVertexNormal;


       float directional = max(dot(uNormalMatrix.xyz, directionalVector), 0.0);
       vLighting = ambientLight + (directionalLightColor * directional);
}

			);

const char *fragmentSource = GLSL(
precision highp float;

uniform sampler2D uTextureUnit;
varying vec2 varTextureCoord0;
varying vec4 varVertexColor;
varying  vec3 vLighting;

vec4 renderSolid()
{
	vec4 Color = varVertexColor;
	Color *= texture2D(uTextureUnit, varTextureCoord0);
	Color.a = 1.0;
	return Color;
}


void main()
{
    //gl_FragColor =vec4(1,1,1,1);// renderSolid();
    //gl_FragColor = renderSolid();
   // gl_FragColor =  texture2D(uTextureUnit, varTextureCoord)  *varVertexColor ;


    vec4 texelColor = renderSolid();// texture2D(uTextureUnit, varTextureCoord0) *varVertexColor ;
    gl_FragColor = vec4(texelColor.rgb * vLighting, texelColor.a);
}

);



//Assets::LoadTexture("media/cube_diffuse.png","cube_diffuse");

IShader *s2 =engine->loadShader(vertexSource,fragmentSource,"LightShader");
s2->setInt("uTextureUnit",0);

}

void createTextureShader()
{



const char* vertexSource = GLSL(

attribute vec3 inVertexPosition;
attribute vec2 inTexCoord0;


uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

varying vec2 varTextureCoord0;


void main()
{

	varTextureCoord0 = inTexCoord0;
    gl_Position = projection * view * model *   vec4(inVertexPosition,1.0);

}

			);

const char *fragmentSource = GLSL(
precision highp float;

uniform sampler2D uTextureUnit;
varying vec2 varTextureCoord0;
varying vec4 varVertexColor;



void main()
{
    vec4 texelColor = texture2D(uTextureUnit, varTextureCoord0);
    gl_FragColor = texelColor;
}

);



//Assets::LoadTexture("media/cube_diffuse.png","cube_diffuse");

IShader *s2 =engine->loadShader(vertexSource,fragmentSource,"Texture");
s2->setInt("uTextureUnit",0);

}

void createSolidShader()
{



const char* vertexSource = GLSL(

attribute vec3 a_position;
attribute vec3 a_color;
varying vec3 v_color;
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
void main()
{
v_color=a_color;
gl_Position = projection * view * model *   vec4(a_position,1.0);
}

			);

const char *fragmentSource = GLSL(
precision highp float;
varying vec3 v_color;
void main()
{
    gl_FragColor = vec4(v_color,1.0);
}

);

engine->loadShader(vertexSource,fragmentSource,"Solid");

}

void createPointsShader()
{


const char* vertexSource = GLSL(

attribute vec3 a_position;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
void main()
{

gl_Position = projection * view * model *   vec4(a_position,1.0);
}

			);

const char *fragmentSource = GLSL(
precision highp float;

void main()
{
    gl_FragColor = vec4(0.04, 0.28, 0.26, 1.0);
}

);

engine->loadShader(vertexSource,fragmentSource,"Points");

}


void createScreenShader()
{
const char* vertexSource = GLSL(

attribute vec3 a_position;
//attribute vec4 a_color;
//varying vec4 v_color;

void main()
{
//v_color=a_color;
gl_Position =  vec4(a_position,1.0);
}

			);

const char *fragmentSource = GLSL(
precision highp float;
//varying vec4 v_color;

void main()
{
  //  gl_FragColor = v_color;//vec4(1.0f, 0.5f, 0.2f, 0.1f);
    gl_FragColor = vec4(0.0f, 0.0f, 0.0f, 0.5f);
}

);

engine->loadShader(vertexSource,fragmentSource,"screenquad");


}


void createStencilShader()
{
const char* vertexSource = GLSL(

attribute vec2 a_position;
void main()
{
gl_Position =  vec4(a_position,0.0,1.0);
}

);

const char *fragmentSource = GLSL(
precision highp float;
void main()
{
    gl_FragColor = vec4(0.0, 0.0, 0.0, 0.4);
}

);

engine->loadShader(vertexSource,fragmentSource,"Stencil");


}

core::matrix4 createTransformation(core::vector3df RelativeTranslation,
core::vector3df RelativeScale =core::vector3df(1.f,1.f,1.f),
core::vector3df RelativeRotation=core::vector3df(0,0,0))
{
    core::matrix4 mat;
    mat.setRotationDegrees(RelativeRotation);
    mat.setTranslation(RelativeTranslation);

    if (RelativeScale != core::vector3df(1.f,1.f,1.f))
    {
        core::matrix4 smat;
        smat.setScale(RelativeScale);
        mat *= smat;
    }

    return mat;
}

int main(int argc, char *args[]) {


if (Init()) return EXIT_FAILURE;

engine=irr::scene::Engine::createEngine(DISP_WIDTH,DISP_HEIGHT);




window_size_callback(DISP_WIDTH,DISP_HEIGHT);

createStencilShader();
createPointsShader();
createScreenShader();
createSolidShader();
createTextureShader();
createlLightTextureShader();



int bufferElements =1000;

for (int i=0;i<bufferElements;i++)
{

vertices.push_back({0.0f,  0.0f, 0.0f, 255,255,255});
vertices.push_back({0.0f,  0.0f, 0.0f ,255,255,255});
vertices.push_back({0.0f,  0.0f, 0.0f ,255,255,255});
vertices.push_back({0.0f,  0.0f, 0.0f ,255,255,255});
}




std::vector<unsigned int> indices;

   int k = 0;

        // Indices can be initialized right now
        for (int j = 0; j < (6*bufferElements); j += 6)
        {
            indices.push_back(4*k);
            indices.push_back( 4*k + 1);
            indices.push_back( 4*k + 2);
            indices.push_back( 4*k);
            indices.push_back( 4*k + 2);
            indices.push_back( 4*k + 3);
            k++;
        }


    std::vector<VertexDeclaration> vfv=
     {
        {VF_POSITION          ,VET_FLOAT3},
        {VF_COLOR        ,VET_BYTE3},
     };

//size_t LengthOfArray = sizeof myArray / sizeof myArray[0];


Tex2d font;
font.Load("media/font.png");


    IVertexBuffer* VertexBuffer= new CVertexBuffer(vfv);
    VertexBuffer->createVBO(vertices.data(),vertices.size(),false);
     DrawGrid(10,0.8f);






//SDL_Log("**************************************");
engine->getTexture("media/rockwall_height.bmp");
engine->getTexture("media/terrain-texture.jpg");
engine->getTexture("media/marble.jpg");
engine->getTexture("media/metal.png");




scene::IAnimatedMesh* meshModel= engine->getGeometryCreator()->importMesh("media/room.3ds");
engine->getMeshManipulator()->makePlanarTextureMapping(meshModel->getMesh(0), 0.004f);
engine->getMeshManipulator()->scale(meshModel->getMesh(0), core::vector3df(0.02f,0.01f,0.02f));
meshModel->getMeshBuffer(0)->getMaterial().setTexture(0,engine->getTexture("media/wall.jpg"));





scene::IAnimatedMesh* quakemd2= engine->getGeometryCreator()->importMesh("media/faerie.md2");
quakemd2->getMeshBuffer(0)->getMaterial().setTexture(0,engine->getTexture("media/faerie2.bmp"));



scene::IMeshAnimator* md2animator = new CMeshAnimator(quakemd2);
md2animator->grab();
md2animator->setMD2Animation(scene::EMAT_POINT);
md2animator->setAnimationSpeed(20.f);
scene::IShadowMesh* md2Shadow= new scene::CShadowMesh(md2animator->getMesh());




scene::IAnimatedMesh* sarge_head= engine->getGeometryCreator()->importMesh("media/sarge/head.md3");
sarge_head->getMeshBuffer(0)->getMaterial().setTexture(0,engine->getTexture("media/sarge/band.jpg"));
sarge_head->getMeshBuffer(0)->getMaterial().setTexture(1,engine->getTexture("media/sarge/cigar.jpg"));



scene::IAnimatedMesh* sarge_lower= engine->getGeometryCreator()->importMesh("media/sarge/lower.md3");
sarge_lower->getMeshBuffer(0)->getMaterial().setTexture(0,engine->getTexture("media/sarge/band.jpg"));
sarge_lower->grab();
scene::IMeshAnimator* sarge_lower_animator= new CMeshAnimator(sarge_lower);
sarge_lower_animator->grab();
sarge_lower_animator->setAnimationSpeed(17.f);
sarge_lower_animator->setFrameLoop(98,109);



scene::IAnimatedMesh* sarge_upper= engine->getGeometryCreator()->importMesh("media/sarge/upper.md3");
sarge_upper->getMeshBuffer(0)->getMaterial().setTexture(0,engine->getTexture("media/sarge/band.jpg"));


scene::IMeshAnimator* sarge_upper_animator= new CMeshAnimator(sarge_upper);
sarge_upper_animator->grab();
sarge_upper_animator->setAnimationSpeed(18);
sarge_upper_animator->setFrameLoop(92,128);



scene::IShadowMesh* md3Shadow[3];

md3Shadow[0]= new scene::CShadowMesh(sarge_head->getMesh(0));


md3Shadow[1]= new scene::CShadowMesh(sarge_upper->getMesh(0));


md3Shadow[2]= new scene::CShadowMesh(sarge_lower->getMesh(0));




     scene::IShadowMesh* cubeShadow;
     scene::IMesh* cube =engine->getGeometryCreator()->createCubeMesh();

     cube->getMeshBuffer(0)->getMaterial().setTexture(0,engine->getTexture("media/marble.jpg"));

     cubeShadow = new scene::CShadowMesh(cube);




     scene::IMesh* cylinder =engine->getGeometryCreator()->createCylinderMesh(0.2f, //radius
                                                                         2.0f, // length
                                                                         10, // tesselation
                                                                         SColor(255, 100, 100, 100), // color
                                                                         true, // closeTop
                                                                         0.0f );// oblique


    cylinder->getMeshBuffer(0)->getMaterial().setTexture(0,engine->getTexture("media/marble.jpg"));

    scene::IShadowMesh* cylinderShadow= new scene::CShadowMesh(cylinder);






    irr::core::dimension2d<irr::f32> tileSize(2.5f,2.5f);
    irr::core::dimension2d<irr::u32> tileCount(4,4);

    irr::f32 hillHeight = 0.0f;
    irr::core::dimension2d<irr::f32> countHills(4.0,4.0);
    irr::core::dimension2d<irr::f32> textureRepeatCount(2.2,4.0);




    auto material = new irr::video::SMaterial();
    material->setTexture(0,engine->getTexture("media/metal.png"));
     scene::IMesh* terrain =engine->getGeometryCreator()->createHillPlaneMesh(  tileSize,
        tileCount,
        material,
        hillHeight,
        countHills,
        textureRepeatCount);












// configure global opengl state
    // -----------------------------



int frame=0;

bool quit = false;
while (!quit)
{

        SDL_Event event;
        while (SDL_PollEvent(&event))
        {

          if (event.type == SDL_WINDOWEVENT && event.window.event == SDL_WINDOWEVENT_CLOSE )
                quit = true;

         switch (event.type)
            {
            case SDL_QUIT:
            {
             quit = true;
             break;
            }
            case SDL_WINDOWEVENT:
            {

                 switch (event.window.event)
                 {
                    case SDL_WINDOWEVENT_CLOSE:
                     {
                     break;
                     }
                     case SDL_WINDOWEVENT_RESIZED:
                     {
                     break;
                     }
                      case SDL_WINDOWEVENT_SIZE_CHANGED:
                     {
                     break;
                     }


                  }
            break;
            }
            case SDL_MOUSEWHEEL:
                {
                       if(event.wheel.y > 0) // scroll up
                        {
                           //  MouseWheel-=1;
                           fov -= 1;
                        }
                        else if(event.wheel.y < 0) // scroll down
                        {
                         fov += 1;
                        }


                    if (fov < 1.0f)
                    fov = 1.0f;
                    if (fov > 45.0f)
                    fov = 45.0f;



                    //pMat = glm::perspective(glm::radians(fov), aspect, 0.1f, 1000.0f); // 1.0472 radians = 60 degrees
                    pMat.buildProjectionMatrixPerspectiveFovRH(core::degToRad(fov),aspect, 0.1f, 1000.0f);
                  break;
                }
            case SDL_MOUSEBUTTONDOWN:
                {
                     isMouseDown=true;
                    break;
                }
              case SDL_MOUSEBUTTONUP:
                {
                     isMouseDown=false;
                    break;
                }
             case SDL_MOUSEMOTION:
                {
                   //if (isTouch)if( templateApp.ToucheMoved ) templateApp.ToucheMoved((float)event.motion.x,(float)event.motion.y,1);


                    break;
                }
            case SDL_TEXTINPUT:
                {
                   // io.AddInputCharactersUTF8(event->text.text);
                    break;
                }
            case SDL_KEYDOWN:
             {
                  break;
            }
            case SDL_KEYUP:
                {
                  break;
                }

        }



    }


    mouse_buttons = SDL_GetMouseState(&mouse_x, &mouse_y);
    state = SDL_GetKeyboardState(NULL);
    if (state[SDL_SCANCODE_ESCAPE])
    {
    quit=true;
    }
    processInput();
    mouse_callback((double)mouse_x,(double)mouse_y);




//   vMat = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
    vMat.buildCameraLookAtMatrixRH(cameraPos, cameraPos + cameraFront, cameraUp);






    engine->BeginScene();

    engine->ClearScene(video::ECBF_COLOR | video::ECBF_DEPTH );


    core::matrix4 model;
    model = model.makeIdentity();


    md2animator->OnAnimate(os::Timer::getTime());
    sarge_lower_animator->OnAnimate(os::Timer::getTime());
    sarge_upper_animator->OnAnimate(os::Timer::getTime());


     IShader* shader = engine->getShader("LightShader");

      engine->setShader(shader);
     shader->setMat4("view",vMat);
     shader->setMat4("projection",pMat);
     shader->setInt("uTextureUnit",0);


    model = model.makeIdentity();
    //model =model.setTranslation(core::vector3df(0.0f,0.0f,0.0f));
    //model =model.setScale(core::vector3df(0.05f,0.05f,0.05f));
    shader->setMat4("model",model);
    engine->renderMesh(meshModel->getMesh(0));


    model = model.makeIdentity();
    model.setTranslation(core::vector3df(0.0f,0.2f,0.0f));
    shader->setMat4("model",model);
    engine->renderMesh(cube);


    // cubes

    model = model.makeIdentity();
    model.setTranslation(core::vector3df(0.0f,0.2f,0.0f));
    shader->setMat4("model",model);
    engine->renderMesh(cube);


    model = model.makeIdentity();
    model.setTranslation(core::vector3df(-1.0f,0.0f,-0.5f));
    shader->setMat4("model",model);
    engine->renderMesh(cylinder);


    model = model.makeIdentity();
    model=createTransformation(core::vector3df(-4.0f,1.5f,-2.0f),core::vector3df(0.05f,0.05f,0.05f));
    shader->setMat4("model",model);
    //engine->renderMesh(quakemd2);
    engine->renderMesh(md2animator->getMesh());







    core::matrix4 legs_model=createTransformation(core::vector3df(2.0f,1.0f,0.0f),core::vector3df(0.05f,0.05f,0.05f));
    shader->setMat4("model",legs_model);
    engine->renderMesh(sarge_lower_animator->getMesh());





    const SMD3QuaternionTag* tag=sarge_lower_animator->getMD3Tag(0);
    core::vector3df pos=core::vector3df(2.0f,1.0f,0.0f)+(tag->position*core::vector3df(0.05f,0.05f,0.05f))+core::vector3df(0.0f,0.1f,0.0f);
    core::matrix4 torso_model=createTransformation(pos,core::vector3df(0.05f,0.05f,0.05f));
    shader->setMat4("model",torso_model);
    engine->renderMesh(sarge_upper_animator->getMesh());





    const SMD3QuaternionTag* tag2=sarge_upper_animator->getMD3Tag(0);
    core::vector3df pos2=pos+(tag2->position*core::vector3df(0.05f,0.05f,0.05f))+core::vector3df(0.0f,0.0f,0.0f);
    core::matrix4 head_model=createTransformation(pos2,core::vector3df(0.05f,0.05f,0.05f));
    shader->setMat4("model",head_model);
    engine->renderMesh(sarge_head->getMesh(0));













shader = engine->getShader("Points");
if (shader)
{
	engine->startStencilTest();
    engine->setShader(shader);

    shader->setMat4("view",vMat);
    shader->setMat4("projection",pMat);
    model = model.makeIdentity();
    model.setTranslation(core::vector3df(0.0f,0.2f,0.0f));
    shader->setMat4("model",model);
    cubeShadow->render(model);


    model.setTranslation(core::vector3df(-1.0f,0.0f,-0.5f));
    shader->setMat4("model",model);
    cylinderShadow->render(model);


    model = model.makeIdentity();
    model=createTransformation(core::vector3df(-4.0f,1.5f,-2.0f),core::vector3df(0.05f,0.05f,0.05f));
    shader->setMat4("model",model);
    md2Shadow->render(model);

    shader->setMat4("model",head_model);
    md3Shadow[0]->render(head_model);

    shader->setMat4("model",torso_model);
    md3Shadow[1]->render(torso_model);

    shader->setMat4("model",legs_model);
    md3Shadow[2]->render(legs_model);

	engine->endStencilTest();

}


shader = engine->getShader("Stencil");
if (shader)
{
engine->setShader(shader);
engine->drawStencilShadow(true);
}














     shader = engine->getShader("Solid");
     if (shader)
     {
         engine->setShader(shader);
         model = model.makeIdentity();
         shader->setMat4("model",model);
         shader->setMat4("view",vMat);
         shader->setMat4("projection",pMat);

        vertices.clear();
        DrawGrid(10,0.8f);
        VertexBuffer->UpdateVertex(vertices.data(),vertices.size());
        VertexBuffer->Render(GL_LINES,  vertices.size());

      }








char text[256];
sprintf(text,"%f sec %d fps", engine->GetFrameTime(),engine->GetFPS() );
font.Print(text, 20, 20, 10.5f);





engine->EndScene();


    SDL_GL_SwapWindow(window);


     // SDL_SetWindowTitle(window,TextFormat("fps[ %d ] %f %f ",GetFPS(),GetFrameTime(),GetTime()));
   SDL_SetWindowTitle(window,TextFormat("%s   fps[ %d ]  %d",TITLE,engine->GetFPS(),sarge_upper_animator->getCurrentFrame()));


}
VertexBuffer->Unload();

md2animator->drop();
cube->drop();
cubeShadow->drop();
cylinder->drop();
cylinderShadow->drop();
terrain->drop();
meshModel->drop();
quakemd2->drop();
md2Shadow->drop();

sarge_lower->drop();
sarge_lower_animator->drop();
sarge_upper->drop();
sarge_upper_animator->drop();
sarge_head->drop();

md3Shadow[0]->drop();
md3Shadow[1]->drop();
md3Shadow[2]->drop();


font.Unload();

engine->drop();
//if(engine) delete engine;

SDL_Log("**************************************************************");
scene::ITransform* transform= new scene::CTransform();
//transform->grab();
transform->drop();
//delete transform;

video::IImage* image = new video::CImage();
//image->grab();
image->drop();
//delete image;

SDL_Log("**************************************************************");
Close();
return EXIT_SUCCESS;
}
