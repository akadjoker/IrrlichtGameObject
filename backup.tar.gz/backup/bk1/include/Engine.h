#ifndef ENGINE_H
#define ENGINE_H


#include "CImage.h"
#include "CShader.h"
#include "COpenGLTexture.h"
#include "CGeometryCreator.h"


#include "os.h"
#include "IrrCompileConfig.h"
#include "aabbox3d.h"
#include "CDynamicMeshBuffer.h"
#include "CIndexBuffer.h"
#include "CMeshBuffer.h"
#include "coreutil.h"
#include "CVertexBuffer.h"

#include "dimension2d.h"
#include "IEngineEnums.h"


#include "fast_atof.h"
#include "heapsort.h"
#include "IAnimatedMesh.h"
#include "IDynamicMeshBuffer.h"
#include "IFileList.h"
#include "IFileSystem.h"
#include "CFileSystem.h"
#include "IGeometryCreator.h"
#include "IImage.h"
#include "IIndexBuffer.h"
#include "ILogger.h"
#include "IMesh.h"
#include "IMeshBuffer.h"
#include "IMeshLoader.h"
#include "IMeshManipulator.h"
#include "IMeshWriter.h"

#include "IReadFile.h"
#include "IReferenceCounted.h"
#include "irrArray.h"
#include "IRandomizer.h"
#include "irrList.h"
#include "irrMap.h"
#include "irrMath.h"
#include "irrString.h"
#include "irrTypes.h"
#include "path.h"
#include "irrXML.h"
#include "ISkinnedMesh.h"
#include "ITexture.h"
#include "ITimer.h"
#include "IVertexBuffer.h"
#include "IWriteFile.h"
#include "IXMLReader.h"
#include "IXMLWriter.h"
#include "line2d.h"
#include "line3d.h"
#include "matrix4.h"
#include "plane3d.h"
#include "position2d.h"
#include "quaternion.h"
#include "rect.h"
#include "S3DVertex.h"
#include "SAnimatedMesh.h"
#include "SColor.h"
#include "SMaterial.h"
#include "SMesh.h"
#include "SSharedMeshBuffer.h"
#include "SSkinMeshBuffer.h"
#include "SViewFrustum.h"
#include "triangle3d.h"
#include "vector2d.h"
#include "vector3d.h"
#include "CWriteFile.h"

namespace irr
{

void ShowSimpleMessageBox(Uint32 flags, const char *title, const char *message);
namespace scene
{

using namespace  video;
using namespace io;



class Engine : public  IReferenceCounted
{
    public:
        Engine(int width, int heigth);
        virtual ~Engine();

    static Engine* Instance();

    static Engine* createEngine(int w,int h);




    ITexture* getTexture(const char* FileName,const char* name);

    double GetTime(void)
    {
    return (double)SDL_GetTicks()/1000;
    }

    float GetFrameTime(void)
    {
    return (float)frame;
    }
    void SetTargetFPS(int fps);
    int GetFPS(void);
    void Wait(float ms);
    void BeginScene();
    void EndScene();

    void renderMesh(IMesh* mesh);
    void renderMeshBuffer(IMeshBuffer* meshBuffer);


    void setAlphaFunc(GLenum mode, GLclampf ref);
    void setAlphaTest(bool enable);


    void setBasicRenderStates(const SMaterial& material, const SMaterial& lastmaterial, bool resetAllRenderStates);
    void setTextureRenderStates(const SMaterial& material, bool resetAllRenderstates);



    void setTexture(const video::ITexture* texture)
	{

	        const COpenGLTexture* tmpTexture =static_cast<const COpenGLTexture*>(texture);

			if (!tmpTexture)
				return;

			GLenum tmpTextureType = tmpTexture->getOpenGLTextureType();
			GLuint tmpTextureName = tmpTexture->getOpenGLTextureName();


			setTexture(tmpTextureType,tmpTextureName);


	}


		void setBlendEquation(GLenum mode)
	{
		if (BlendEquation[0] != mode || BlendEquationInvalid)
		{
             glBlendEquation(mode);

			for (GLuint i = 0; i < FrameBufferCount; ++i)
				BlendEquation[i] = mode;

			BlendEquationInvalid = false;
		}
	}



	void setBlendFunc(GLenum source, GLenum destination)
	{
		if (BlendSourceRGB[0] != source || BlendDestinationRGB[0] != destination ||
			BlendSourceAlpha[0] != source || BlendDestinationAlpha[0] != destination ||
			BlendFuncInvalid)
		{
			glBlendFunc(source, destination);

			for (GLuint i = 0; i < FrameBufferCount; ++i)
			{
				BlendSourceRGB[i] = source;
				BlendDestinationRGB[i] = destination;
				BlendSourceAlpha[i] = source;
				BlendDestinationAlpha[i] = destination;
			}

			BlendFuncInvalid = false;
		}
	}

	void setBlendFuncSeparate(GLenum sourceRGB, GLenum destinationRGB, GLenum sourceAlpha, GLenum destinationAlpha)
	{
		if (sourceRGB != sourceAlpha || destinationRGB != destinationAlpha)
		{
			if (BlendSourceRGB[0] != sourceRGB || BlendDestinationRGB[0] != destinationRGB ||
				BlendSourceAlpha[0] != sourceAlpha || BlendDestinationAlpha[0] != destinationAlpha ||
				BlendFuncInvalid)
			{
                 glBlendFuncSeparate(sourceRGB, destinationRGB, sourceAlpha, destinationAlpha);

				for (GLuint i = 0; i < FrameBufferCount; ++i)
				{
					BlendSourceRGB[i] = sourceRGB;
					BlendDestinationRGB[i] = destinationRGB;
					BlendSourceAlpha[i] = sourceAlpha;
					BlendDestinationAlpha[i] = destinationAlpha;
				}

				BlendFuncInvalid = false;
			}
		}
		else
		{
			setBlendFunc(sourceRGB, destinationRGB);
		}
	}


	void setBlend(bool enable)
	{
		if (Blend[0] != enable || BlendInvalid)
		{
			if (enable)
				glEnable(GL_BLEND);
			else
				glDisable(GL_BLEND);

			for (GLuint i = 0; i < FrameBufferCount; ++i)
				Blend[i] = enable;

			BlendInvalid = false;
		}
	}



	// Color Mask.

	void getColorMask(u8& mask)
	{
		mask = ColorMask[0];
	}

	void setColorMask(u8 mask)
	{
		if (ColorMask[0] != mask || ColorMaskInvalid)
		{
			glColorMask((mask & ECP_RED) ? GL_TRUE : GL_FALSE, (mask & ECP_GREEN) ? GL_TRUE : GL_FALSE, (mask & ECP_BLUE) ? GL_TRUE : GL_FALSE, (mask & ECP_ALPHA) ? GL_TRUE : GL_FALSE);

			for (GLuint i = 0; i < FrameBufferCount; ++i)
				ColorMask[i] = mask;

			ColorMaskInvalid = false;
		}
	}



	// Cull face calls.

	void setCullFaceFunc(GLenum mode)
	{
		if (CullFaceMode != mode)
		{
			glCullFace(mode);
			CullFaceMode = mode;
		}
	}

	void setCullFace(bool enable)
	{
		if (CullFace != enable)
		{
			if (enable)
				glEnable(GL_CULL_FACE);
			else
				glDisable(GL_CULL_FACE);

			CullFace = enable;
		}
	}

	// Depth calls.

	void setDepthFunc(GLenum mode)
	{
		if (DepthFunc != mode)
		{
			glDepthFunc(mode);
			DepthFunc = mode;
		}
	}

	void getDepthMask(bool& depth)
	{
		depth = DepthMask;
	}

	void setDepthMask(bool enable)
	{
		if (DepthMask != enable)
		{
			if (enable)
				glDepthMask(GL_TRUE);
			else
				glDepthMask(GL_FALSE);

			DepthMask = enable;
		}
	}

    void getDepthTest(bool& enable)
    {
        enable = DepthTest;
    }

	void setDepthTest(bool enable)
	{
		if (DepthTest != enable)
		{
			if (enable)
				glEnable(GL_DEPTH_TEST);
			else
				glDisable(GL_DEPTH_TEST);

			DepthTest = enable;
		}
	}

	// FBO calls.

	void getFBO(GLuint& frameBufferID) const
	{
		frameBufferID = FrameBufferID;
	}

	void setFBO(GLuint frameBufferID)
	{
		if (FrameBufferID != frameBufferID)
		{
			glBindFramebuffer(GL_FRAMEBUFFER, frameBufferID);
			FrameBufferID = frameBufferID;
		}
	}

	// Shaders calls.

	void getProgram(GLuint& programID) const
	{
		programID = ProgramID;
	}

	void setProgram(GLuint programID)
	{
		if (ProgramID != programID)
		{
			glUseProgram(programID);
			ProgramID = programID;
		}
	}

	// Texture calls.

	void getActiveTexture(GLenum& texture) const
	{
		texture = ActiveTexture;
	}

	void setActiveTexture(GLenum texture)
	{
		if (ActiveTexture != texture)
		{
			glActiveTexture(texture);
			ActiveTexture = texture;

		}
	}

	void setTexture(GLuint type,GLuint texture)
	{
		if (CurrTexture != texture)
		{
			glBindTexture(type, texture);
			CurrTexture = texture;

		}
	}
	// Viewport calls.

	void getViewport(GLint& viewportX, GLint& viewportY, GLsizei& viewportWidth, GLsizei& viewportHeight) const
	{
		viewportX = ViewportX;
		viewportY = ViewportY;
		viewportWidth = ViewportWidth;
		viewportHeight = ViewportHeight;
	}

	void setViewport(GLint viewportX, GLint viewportY, GLsizei viewportWidth, GLsizei viewportHeight)
	{
		if (ViewportX != viewportX || ViewportY != viewportY || ViewportWidth != viewportWidth || ViewportHeight != viewportHeight)
		{
			glViewport(viewportX, viewportY, viewportWidth, viewportHeight);
			ViewportX = viewportX;
			ViewportY = viewportY;
			ViewportWidth = viewportWidth;
			ViewportHeight = viewportHeight;
		}
	}


	IFileSystem*      getFileSystem(){return FileSystem;};
    IMeshManipulator* getMeshManipulator(){return MeshManipulator;};
    IGeometryCreator* getGeometryCreator(){return GeometryCreator;};



		bool getWriteZBuffer(const SMaterial& material) const
		{
		return 	 material.ZWriteEnable && !material.isTransparent();
		}
		GLenum getGLBlend(E_BLEND_FACTOR factor) const
	{
		static GLenum const blendTable[] =
		{
			GL_ZERO,
			GL_ONE,
			GL_DST_COLOR,
			GL_ONE_MINUS_DST_COLOR,
			GL_SRC_COLOR,
			GL_ONE_MINUS_SRC_COLOR,
			GL_SRC_ALPHA,
			GL_ONE_MINUS_SRC_ALPHA,
			GL_DST_ALPHA,
			GL_ONE_MINUS_DST_ALPHA,
			GL_SRC_ALPHA_SATURATE
		};

		return blendTable[factor];
	}

	GLenum getZBufferBits() const
	{
		// TODO: never used, so not sure what this was really about (zbuffer used by device? Or for RTT's?)

		GLenum bits = 0;
//				bits = GL_DEPTH_COMPONENT24_OES;
				bits = GL_DEPTH_COMPONENT16;

		return bits;
	}

		GLint getTextureWrapMode(u8 clamp) const
	{
		switch (clamp)
		{
			case ETC_CLAMP:
			case ETC_CLAMP_TO_EDGE:
			case ETC_CLAMP_TO_BORDER:
				return GL_CLAMP_TO_EDGE;
			case ETC_MIRROR:
				return GL_REPEAT;
			default:
				return GL_REPEAT;
		}
    }

    void setMaterial(const SMaterial& material);

    //! deletes all textures
		void deleteAllTextures();

		//! opens the file and loads it into the surface
		video::ITexture* loadTextureFromFile(io::IReadFile* file, const io::path& hashName = "");


		//! adds a surface, not loaded or created by the Irrlicht Engine
		void addTexture(video::ITexture* surface);

		//! looks if the image is already loaded
		 video::ITexture* findTexture(const io::path& filename);
		//! Removes a texture from the texture cache and deletes it, freeing lot of
		//! memory.
		 void removeTexture(ITexture* texture);

		//! Removes all texture from the texture cache and deletes them, freeing lot of
		//! memory.
		 void removeAllTextures();





	//	 ITexture* getTexture(const char* filename);

		//! loads a Texture
		 ITexture* getTexture(const io::path& filename);

		//! loads a Texture
		 ITexture* getTexture(io::IReadFile* file);

		//! Returns a texture by index
		 ITexture* getTextureByIndex(u32 index);

		//! Returns amount of textures currently loaded
		 u32 getTextureCount() const;

		//! Renames a texture
		 void renameTexture(ITexture* texture, const io::path& newName);

		 		//! Creates a software image from a file.
		 IImage* createImageFromFile(const io::path& filename);

		//! Creates a software image from a file.
		 IImage* createImageFromFile(io::IReadFile* file);

		  IImage* createImageFromData(ECOLOR_FORMAT format,
			const core::dimension2d<u32>& size, void *data,
			bool ownForeignMemory=true, bool deleteForeignMemory = true);

		//! Creates an empty software image.
		 IImage* createImage(ECOLOR_FORMAT format, const core::dimension2d<u32>& size);

		 IImage* createImage(ITexture* texture, const core::position2d<s32>& pos, const core::dimension2d<u32>& size);


        bool writeImageToFile(IImage* image, const io::path& filename);
        bool writeImageToFile(IImage* image, io::IWriteFile * file);


        IShader* loadShaderFromFile(const char* vertexPath, const char* fragmentPath,const char* ID);
        IShader* loadShader(const char* vertexPath, const char* fragmentPath,const char* ID);
        IShader* getShader(const char* ID);
        void setShader(IShader* shader);
        IShader* setShader(const char* ID);



    protected:


    private:

    IFileSystem      *FileSystem;
    IMeshManipulator *MeshManipulator;
    IGeometryCreator *GeometryCreator;

    double current;                     // Current time measure
	double previous;                    // Previous time measure
	double update;                      // Time measure for frame update
	double draw;                        // Time measure for frame draw
	double frame;                       // Time measure for one frame
	double target;                      // Desired time for one frame, if 0 not applied

	//gl states
			float DimAliasedLine[2];
			float DimAliasedPoint[2];
    	GLenum AlphaMode;
		GLclampf AlphaRef;
		bool AlphaTest;
		GLenum MatrixMode;
		GLenum ClientActiveTexture;




	GLuint FrameBufferCount;

	GLenum* BlendEquation;
	GLenum* BlendSourceRGB;
	GLenum* BlendDestinationRGB;
	GLenum* BlendSourceAlpha;
	GLenum* BlendDestinationAlpha;
	bool* Blend;
	bool BlendEquationInvalid;
	bool BlendFuncInvalid;
	bool BlendInvalid;


	u8* ColorMask;
	bool ColorMaskInvalid;

	GLenum CullFaceMode;
	bool CullFace;

	GLenum DepthFunc;
	bool DepthMask;
	bool DepthTest;
    u8 MaxAnisotropicFilter;

	GLuint FrameBufferID;

	GLuint ProgramID;

	GLenum ActiveTexture;
	GLenum CurrTexture;
	SMaterial currMaterial,LastMaterial;

	GLint ViewportX;
	GLint ViewportY;
	GLsizei ViewportWidth;
	GLsizei ViewportHeight;

    core::array<ITexture*> Textures;
    //core::array<IShader*>  Shaders;
    core::map<const char*,IShader*>  Shaders;

    //core::map<irr::core::stringc, bool> MaterialsWritten;


};
}
}
#endif // ENGINE_H
