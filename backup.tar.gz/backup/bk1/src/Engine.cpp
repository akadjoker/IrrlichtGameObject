#include "Engine.h"

#include "CMeshManipulator.h"
#include "CImage.h"
#include "COpenGLTexture.h"
#include "CGeometryCreator.h"


extern SDL_Window *window;
namespace irr
{
static scene::Engine *theInstance;
extern  s32 ReferenceCounter;


void ShowSimpleMessageBox(Uint32 flags, const char *title, const char *message)
{
SDL_ShowSimpleMessageBox(flags,
                         title,
                         message,
                         window);
}


namespace scene
{

Engine::Engine(int Width, int Height):AlphaMode(GL_ALWAYS), AlphaRef(0.f), AlphaTest(false),FrameBufferCount(0), BlendEquation(0), BlendSourceRGB(0),
		BlendDestinationRGB(0), BlendSourceAlpha(0), BlendDestinationAlpha(0), Blend(0), BlendEquationInvalid(false), BlendFuncInvalid(false), BlendInvalid(false),
		ColorMask(0), ColorMaskInvalid(false), CullFaceMode(GL_BACK), CullFace(false), DepthFunc(GL_LESS), DepthMask(true), DepthTest(false), FrameBufferID(0),
		ProgramID(0), ActiveTexture(GL_TEXTURE0), ViewportX(0), ViewportY(0)
{
setDebugName("Engine");
theInstance = this;

os::Printer::log("[ENGINE] Init", ELL_INFORMATION);

srand((unsigned int)SDL_GetTicks());    // Initialize random seed
previous = GetTime();     // Get time as double
current = GetTime();            // Number of elapsed seconds since InitTimer()
update = current - previous;
previous = current;

currMaterial=IdentityMaterial;
LastMaterial=IdentityMaterial;

FrameBufferCount =8;

os::Printer::log("[ENGINE] Setup defaults  . ", ELL_INFORMATION);
os::Printer::print(ELL_INFORMATION,"GL: OpenGL device information:");
os::Printer::print(ELL_INFORMATION,"    > Vendor:   %s", glGetString(GL_VENDOR));
os::Printer::print(ELL_INFORMATION,"    > Renderer: %s", glGetString(GL_RENDERER));
os::Printer::print(ELL_INFORMATION,"    > Version:  %s", glGetString(GL_VERSION));
os::Printer::print(ELL_INFORMATION,"    > GLSL:     %s", glGetString(GL_SHADING_LANGUAGE_VERSION));



    // Get supported extensions list
    GLint numExt = 0;
    const char **extList =(const char**) malloc(512*sizeof(const char *)); // Allocate 512 strings pointers (2 KB)
    const char *extensions = (const char *)glGetString(GL_EXTENSIONS);  // One big const string

    // NOTE: We have to duplicate string because glGetString() returns a const string
    int len = strlen(extensions) + 1;
    char *extensionsDup = (char *)calloc(len, sizeof(char));
    strcpy(extensionsDup, extensions);
    extList[numExt] = extensionsDup;

    for (int i = 0; i < len; i++)
    {
        if (extensionsDup[i] == ' ')
        {
            extensionsDup[i] = '\0';
            numExt++;
            extList[numExt] = &extensionsDup[i + 1];
        }
    }

    bool texNPOT=false;
    os::Printer::print(ELL_INFORMATION, "GL: Supported extensions count: %i", numExt);
//    os::Printer::print(ELL_INFORMATION, "GL: OpenGL extensions:");
  //  for (int i = 0; i < numExt; i++) os::Printer::print(ELL_INFORMATION, "    %s", extList[i]);

    // Check required extensions
    for (int i = 0; i < numExt; i++)
    {
        // Check VAO support
        // NOTE: Only check on OpenGL ES, OpenGL 3.3 has VAO support as core feature
        if (strcmp(extList[i], (const char *)"GL_OES_vertex_array_object") == 0)
        {
          //extvao = true;
        }

        // Check instanced rendering support
        if (strcmp(extList[i], (const char *)"GL_ANGLE_instanced_arrays") == 0)         // Web ANGLE
        {
          //extinstancing = true;
        }
        else
        {
            if ((strcmp(extList[i], (const char *)"GL_EXT_draw_instanced") == 0) &&     // Standard EXT
                (strcmp(extList[i], (const char *)"GL_EXT_instanced_arrays") == 0))
            {
              // extinstancing = true;
            }
        }


        // Check NPOT textures support
        // NOTE: Only check on OpenGL ES, OpenGL 3.3 has NPOT textures full support as core feature
        if (strcmp(extList[i], (const char *)"GL_OES_texture_npot") == 0) texNPOT = true;

        // Check texture float support
        //if (strcmp(extList[i], (const char *)"GL_OES_texture_float") == 0) texFloat32 = true;

        // Check depth texture support
       // if ((strcmp(extList[i], (const char *)"GL_OES_depth_texture") == 0) ||
      //      (strcmp(extList[i], (const char *)"GL_WEBGL_depth_texture") == 0)) texDepth = true;

      //  if (strcmp(extList[i], (const char *)"GL_OES_depth24") == 0) maxDepthBits = 24;
      //  if (strcmp(extList[i], (const char *)"GL_OES_depth32") == 0) maxDepthBits = 32;


    }

    // Free extensions pointers
    free(extList);
    free(extensionsDup);    // Duplicated string must be deallocated


		BlendEquation = new GLenum[FrameBufferCount];
		BlendSourceRGB = new GLenum[FrameBufferCount];
		BlendDestinationRGB = new GLenum[FrameBufferCount];
		BlendSourceAlpha = new GLenum[FrameBufferCount];
		BlendDestinationAlpha = new GLenum[FrameBufferCount];
		Blend = new bool[FrameBufferCount];
		ColorMask = new u8[FrameBufferCount];

		// Initial OpenGL values from specification.


			glBlendEquation(GL_FUNC_ADD);


		for (u32 i = 0; i < FrameBufferCount; ++i)
		{
			BlendEquation[i] = GL_FUNC_ADD;

			BlendSourceRGB[i] = GL_ONE;
			BlendDestinationRGB[i] = GL_ZERO;
			BlendSourceAlpha[i] = GL_ONE;
			BlendDestinationAlpha[i] = GL_ZERO;

			Blend[i] = false;
			ColorMask[i] = ECP_ALL;
		}

		glBlendFunc(GL_ONE, GL_ZERO);
		glDisable(GL_BLEND);

		glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);

		glCullFace(CullFaceMode);
		glDisable(GL_CULL_FACE);

		glDepthFunc(DepthFunc);
		glDepthMask(GL_TRUE);
		glDisable(GL_DEPTH_TEST);

		glActiveTexture(ActiveTexture);

		glDisable(GL_TEXTURE_2D);


		ViewportWidth = Width;
		ViewportHeight =Height;
		glViewport(ViewportX, ViewportY, ViewportWidth, ViewportHeight);

glGetFloatv(GL_ALIASED_LINE_WIDTH_RANGE, DimAliasedLine);
glGetFloatv(GL_ALIASED_POINT_SIZE_RANGE, DimAliasedPoint);

glPixelStorei(GL_PACK_ALIGNMENT, 1);

glClearDepthf(1.0f);

glHint(GL_GENERATE_MIPMAP_HINT, GL_NICEST);
//glFrontFace(GL_CW);

//glAlphaFunc(AlphaMode, AlphaRef);
//glDisable(GL_ALPHA_TEST);

//glViewport(0, 0, screenSize.Width, screenSize.Height); // Reset The Current Viewport
//glShadeModel(GL_SMOOTH);
//setAmbientLight(SColor(0,0,0,0));

//glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
glDepthFunc(GL_LEQUAL);


GLint mxaf=0;
glGetIntegerv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &mxaf);
MaxAnisotropicFilter=(u8)mxaf;

os::Printer::log("[ENGINE] Create File System  . ", ELL_INFORMATION);
FileSystem      = new CFileSystem();
FileSystem->grab();
os::Printer::log("[ENGINE] Create Mesh Manipulator . ", ELL_INFORMATION);
MeshManipulator = new CMeshManipulator();
MeshManipulator->grab();
os::Printer::log("[ENGINE] Create Geometry Creator . ", ELL_INFORMATION);
GeometryCreator = new CGeometryCreator();
GeometryCreator->grab();

grab();
}

Engine::~Engine()
{

//s32 obj_total = ReferenceCounter;


os::Printer::log("[ENGINE] Free ", ELL_INFORMATION);
os::Printer::log("[ENGINE] Free File System  . ", ELL_INFORMATION);
FileSystem->drop();
delete FileSystem;
os::Printer::log("[ENGINE] Free Mesh Manipulator . ", ELL_INFORMATION);
MeshManipulator->drop();
delete MeshManipulator;
os::Printer::log("[ENGINE] Free Geometry Creator . ", ELL_INFORMATION);
GeometryCreator->drop();
delete GeometryCreator;
os::Printer::log("[ENGINE] Free Texture List . ", ELL_INFORMATION);
deleteAllTextures();

//SDL_Log(" Free (%d) objects from %d",ReferenceCounter,obj_total);

drop();
}
ITexture* Engine::getTexture(const char* FileName,const char* name)
{
  ITexture* texture;

  return texture;
}
Engine* Engine::Instance()
{
return theInstance;
}

Engine* Engine::createEngine(int w,int h)
{
  Engine* eng = new  Engine(w,h);
  eng->grab();
  return eng;
}
void Engine::BeginScene()
{
current = GetTime();            // Number of elapsed seconds since InitTimer()
update = current - previous;
previous = current;

   glClearColor(0.0f, 0.0f, 0.4f, 1.0f);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}
void Engine::SetTargetFPS(int fps)
{
	if (fps < 1) target = 0.0;
	else target = 1.0/(double)fps;


}
void Engine::Wait(float ms)
{

	#define MAX_HALFBUSY_WAIT_TIME  4
	double prevTime = GetTime();
	double nextTime = 0.0;
	// Busy wait loop
	while ((nextTime - prevTime) < ms/1000.0f) nextTime = GetTime();

//SDL_Delay((Uint32)ms);


}
int Engine::GetFPS(void)
{
    #define FPS_CAPTURE_FRAMES_COUNT    30      // 30 captures
    #define FPS_AVERAGE_TIME_SECONDS   0.5f     // 500 millisecondes
    #define FPS_STEP (FPS_AVERAGE_TIME_SECONDS/FPS_CAPTURE_FRAMES_COUNT)

    static int index = 0;
    static float history[FPS_CAPTURE_FRAMES_COUNT] = { 0 };
    static float average = 0, last = 0;
    float fpsFrame = GetFrameTime();

    if (fpsFrame == 0) return 0;

    if ((GetTime() - last) > FPS_STEP)
    {
        last = (float)GetTime();
        index = (index + 1)%FPS_CAPTURE_FRAMES_COUNT;
        average -= history[index];
        history[index] = fpsFrame/FPS_CAPTURE_FRAMES_COUNT;
        average += history[index];
    }

    return (int)roundf(1.0f/average);
}

void Engine::EndScene()
{
    current = GetTime();
	draw = current - previous;
	previous = current;

	frame = update + draw;

    // Wait for some milliseconds...
	if (frame < target)
    {
		Wait((float)(target - frame)*1000.0f);

		current = GetTime();
		double waitTime = current - previous;
		previous = current;

		frame += waitTime;      // Total frame time: update + draw + wait
	}

    glDisableVertexAttribArray(0);
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(2);
    glDisableVertexAttribArray(3);
    glDisableVertexAttribArray(4);
    glDisableVertexAttribArray(5);
    glDisableVertexAttribArray(6);


	glBindVertexArray(0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

//****************************OPENGL


void Engine::setAlphaTest(bool enable)
{
	if (AlphaTest != enable)
	{
	/*	if (enable)
			glEnable(GL_ALPHA_TEST);
		else
			glDisable(GL_ALPHA_TEST);*/
		AlphaTest = enable;
	}
}
void Engine::setMaterial(const SMaterial& material)
{
 // if (LastMaterial!=material)
  {
    setBasicRenderStates(material,LastMaterial,false);
    LastMaterial=material;
   // SDL_Log("%s ",material.getTexture(0)->getName());
  }

}

void Engine::renderMesh(IMesh* mesh)
{
    for (u32 i=0; i<mesh->getMeshBufferCount(); ++i)
    {
       IMeshBuffer* meshBuffer =mesh->getMeshBuffer(i);
       if(meshBuffer)
       {
        renderMeshBuffer(meshBuffer);
       }
    }



}
void Engine::renderMeshBuffer(IMeshBuffer* meshBuffer)
{
    int PrimitiveCount            =meshBuffer->getPrimitiveCount();
    E_PRIMITIVE_TYPE primitiveType=meshBuffer->getPrimitiveType();
    video::SMaterial material=meshBuffer->getMaterial();
    setMaterial(material);
    meshBuffer->render(PrimitiveCount,primitiveType);
}




void Engine::setBasicRenderStates(const SMaterial& material, const SMaterial& lastmaterial, bool resetAllRenderStates)
	{





		// ZBuffer
		switch (material.ZBuffer)
		{
			case ECFN_DISABLED:
				setDepthTest(false);
				break;
			case ECFN_LESSEQUAL:
				setDepthTest(true);
				setDepthFunc(GL_LEQUAL);
				break;
			case ECFN_EQUAL:
				setDepthTest(true);
				setDepthFunc(GL_EQUAL);
				break;
			case ECFN_LESS:
				setDepthTest(true);
				setDepthFunc(GL_LESS);
				break;
			case ECFN_NOTEQUAL:
				setDepthTest(true);
				setDepthFunc(GL_NOTEQUAL);
				break;
			case ECFN_GREATEREQUAL:
				setDepthTest(true);
				setDepthFunc(GL_GEQUAL);
				break;
			case ECFN_GREATER:
				setDepthTest(true);
				setDepthFunc(GL_GREATER);
				break;
			case ECFN_ALWAYS:
				setDepthTest(true);
				setDepthFunc(GL_ALWAYS);
				break;
			case ECFN_NEVER:
				setDepthTest(true);
				setDepthFunc(GL_NEVER);
				break;
			default:
				break;
		}

	//	glEnable(GL_DEPTH_TEST);
	////	glDisable(GL_DEPTH_TEST);



		// ZWrite
		if (getWriteZBuffer(material))
		{
			setDepthMask(true);
		}
		else
		{
			setDepthMask(false);
		}


		// Back face culling
		if ((material.FrontfaceCulling) && (material.BackfaceCulling))
		{
			setCullFaceFunc(GL_FRONT_AND_BACK);
			setCullFace(true);
		}
		else if (material.BackfaceCulling)
		{
			setCullFaceFunc(GL_BACK);
			setCullFace(true);
		}
		else if (material.FrontfaceCulling)
		{
			setCullFaceFunc(GL_FRONT);
			setCullFace(true);
		}
		else
		{
			setCullFace(false);
		}





		// Color Mask
		setColorMask(material.ColorMask);


		// Blend Equation
		if (material.BlendOperation == EBO_NONE)
			setBlend(false);
		else
		{
			setBlend(true);

			switch (material.BlendOperation)
			{
			case EBO_ADD:
				setBlendEquation(GL_FUNC_ADD);
				break;
			case EBO_SUBTRACT:
				setBlendEquation(GL_FUNC_SUBTRACT);
				break;
			case EBO_REVSUBTRACT:
				setBlendEquation(GL_FUNC_REVERSE_SUBTRACT);
				break;
			default:
				break;
			}
		}



		// Blend Factor
		if (IR(material.BlendFactor) & 0xFFFFFFFF	// TODO: why the & 0xFFFFFFFF?
			&& material.MaterialType != EMT_ONETEXTURE_BLEND
		)
		{
		    E_BLEND_FACTOR srcRGBFact = EBF_ZERO;
		    E_BLEND_FACTOR dstRGBFact = EBF_ZERO;
		    E_BLEND_FACTOR srcAlphaFact = EBF_ZERO;
		    E_BLEND_FACTOR dstAlphaFact = EBF_ZERO;
		    E_MODULATE_FUNC modulo = EMFN_MODULATE_1X;
		    u32 alphaSource = 0;

		    unpack_textureBlendFuncSeparate(srcRGBFact, dstRGBFact, srcAlphaFact, dstAlphaFact, modulo, alphaSource, material.BlendFactor);
			setBlendFuncSeparate(getGLBlend(srcRGBFact), getGLBlend(dstRGBFact),getGLBlend(srcAlphaFact), getGLBlend(dstAlphaFact));
		}

		// TODO: Polygon Offset. Not sure if it was left out deliberately or if it won't work with this driver.

		if (resetAllRenderStates || lastmaterial.Thickness != material.Thickness)
			glLineWidth(core::clamp(static_cast<GLfloat>(material.Thickness), DimAliasedLine[0], DimAliasedLine[1]));

		// Anti aliasing
		if (resetAllRenderStates || lastmaterial.AntiAliasing != material.AntiAliasing)
		{
			if (material.AntiAliasing & EAAM_ALPHA_TO_COVERAGE)
				glEnable(GL_SAMPLE_ALPHA_TO_COVERAGE);
			else if (lastmaterial.AntiAliasing & EAAM_ALPHA_TO_COVERAGE)
				glDisable(GL_SAMPLE_ALPHA_TO_COVERAGE);
		}


		// Texture parameters
		setTextureRenderStates(material, resetAllRenderStates);

	}

    void Engine::setTextureRenderStates(const SMaterial& material, bool resetAllRenderstates)
	{
/*
	    for (s32 i = _IRR_MATERIAL_MAX_TEXTURES_ - 1; i >= 0; --i)
		{
			const COpenGLTexture* tmpTexture =static_cast<const COpenGLTexture*>(material.TextureLayer[i].Texture);

			if (!tmpTexture)
				continue;

			GLuint tmpTextureType = tmpTexture->getOpenGLTextureType();
			GLuint tmpTextureName = tmpTexture->getOpenGLTextureName();

			//SDL_Log("%d %d",tmpTextureName,tmpTextureType);


			setActiveTexture(GL_TEXTURE0 + i);
			setTexture(tmpTextureType,tmpTextureName);
        }
*/
	//   if (material!=currMaterial)
	   {

		// Set textures to TU/TIU and apply filters to them
		int MaxTextureUnits=4;

		for (s32 i = MaxTextureUnits - 1; i >= 0; --i)
		{
			const COpenGLTexture* tmpTexture =static_cast<const COpenGLTexture*>(material.TextureLayer[i].Texture);

			if (!tmpTexture)
				continue;

			GLenum tmpTextureType = tmpTexture->getOpenGLTextureType();
			GLuint tmpTextureName = tmpTexture->getOpenGLTextureName();

			setActiveTexture(GL_TEXTURE0 + i);
			setTexture(tmpTextureType,tmpTextureName);


			if (! material.TextureLayer[i].BilinearFilter !=currMaterial.TextureLayer[i].BilinearFilter ||
				material.TextureLayer[i].TrilinearFilter != currMaterial.TextureLayer[i].TrilinearFilter)
			{
				glTexParameteri(tmpTextureType, GL_TEXTURE_MAG_FILTER,(material.TextureLayer[i].BilinearFilter || material.TextureLayer[i].TrilinearFilter) ? GL_LINEAR : GL_NEAREST);

				currMaterial.TextureLayer[i].BilinearFilter = material.TextureLayer[i].BilinearFilter;
				currMaterial.TextureLayer[i].TrilinearFilter = material.TextureLayer[i].TrilinearFilter;
			}

			if (material.UseMipMaps )
			{
				if ( material.TextureLayer[i].BilinearFilter != currMaterial.TextureLayer[i].BilinearFilter ||
					material.TextureLayer[i].TrilinearFilter != currMaterial.TextureLayer[i].TrilinearFilter )
				{
					glTexParameteri(tmpTextureType, GL_TEXTURE_MIN_FILTER,
						material.TextureLayer[i].TrilinearFilter ? GL_LINEAR_MIPMAP_LINEAR :
						material.TextureLayer[i].BilinearFilter ? GL_LINEAR_MIPMAP_NEAREST :
						GL_NEAREST_MIPMAP_NEAREST);

					currMaterial.TextureLayer[i].BilinearFilter = material.TextureLayer[i].BilinearFilter;
					currMaterial.TextureLayer[i].TrilinearFilter = material.TextureLayer[i].TrilinearFilter;

				}
			}
			else
			{
				if ( material.TextureLayer[i].BilinearFilter != currMaterial.TextureLayer[i].BilinearFilter ||
					material.TextureLayer[i].TrilinearFilter != currMaterial.TextureLayer[i].TrilinearFilter )
				{
					glTexParameteri(tmpTextureType, GL_TEXTURE_MIN_FILTER,
						(material.TextureLayer[i].BilinearFilter || material.TextureLayer[i].TrilinearFilter) ? GL_LINEAR : GL_NEAREST);

					currMaterial.TextureLayer[i].BilinearFilter = material.TextureLayer[i].BilinearFilter;
					currMaterial.TextureLayer[i].TrilinearFilter = material.TextureLayer[i].TrilinearFilter;

				}
			}





           if( material.TextureLayer[i].AnisotropicFilter !=  currMaterial.TextureLayer[i].AnisotropicFilter)
			{
				glTexParameteri(tmpTextureType, GL_TEXTURE_MAX_ANISOTROPY_EXT,
				material.TextureLayer[i].AnisotropicFilter>1 ? core::min_(MaxAnisotropicFilter, material.TextureLayer[i].AnisotropicFilter) : 1);
    			 currMaterial.TextureLayer[i].AnisotropicFilter = material.TextureLayer[i].AnisotropicFilter;
    			 //glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, anisoset);
			}


			if ( material.TextureLayer[i].TextureWrapU != currMaterial.TextureLayer[i].TextureWrapU)
			{
				glTexParameteri(tmpTextureType, GL_TEXTURE_WRAP_S, getTextureWrapMode(material.TextureLayer[i].TextureWrapU));
				currMaterial.TextureLayer[i].TextureWrapU = material.TextureLayer[i].TextureWrapU;
			}

			if ( material.TextureLayer[i].TextureWrapV != currMaterial.TextureLayer[i].TextureWrapV)
			{
				glTexParameteri(tmpTextureType, GL_TEXTURE_WRAP_T, getTextureWrapMode(material.TextureLayer[i].TextureWrapV));
				currMaterial.TextureLayer[i].TextureWrapV = material.TextureLayer[i].TextureWrapV;
			}


		}
		currMaterial=material;
		}

	}

	//! Removes a texture from the texture cache and deletes it, freeing lot of
//! memory.
void Engine::removeTexture(ITexture* texture)
{
	if (!texture)
		return;

	for (u32 i=0; i<Textures.size(); ++i)
	{
		if (Textures[i] == texture)
		{
			texture->drop();
			Textures.erase(i);
		}
	}
}


//! Removes all texture from the texture cache and deletes them, freeing lot of
//! memory.
void Engine::removeAllTextures()
{

	deleteAllTextures();
}


//! Returns a texture by index
ITexture* Engine::getTextureByIndex(u32 i)
{
	if ( i < Textures.size() )
		return Textures[i];

	return 0;
}

//! deletes all textures
void Engine::deleteAllTextures()
{
	// we need to remove previously set textures which might otherwise be kept in the
	// last set material member. Could be optimized to reduce state changes.
	setMaterial(SMaterial());

	for (u32 i=0; i<Textures.size(); ++i)
	{

	    video::COpenGLTexture* tex=(video::COpenGLTexture*)Textures[i];
	    if(tex)
	    {
	    tex->grab();

	    //SDL_Log("free texture : %d  %s  id[%d]",i,tex->getName().getInternalName().c_str(),tex->getOpenGLTextureName());
	    if (!tex->drop())
		if(tex)
		{
		  delete tex;
          tex=nullptr;

		}
        }
	}


	Textures.clear();
}

//! Returns amount of textures currently loaded
u32 Engine::getTextureCount() const
{
	return Textures.size();
}


//! Renames a texture
void Engine::renameTexture(ITexture* texture, const io::path& newName)
{
	// we can do a const_cast here safely, the name of the ITexture interface
	// is just readonly to prevent the user changing the texture name without invoking
	// this method, because the textures will need resorting afterwards

	io::SNamedPath& name = const_cast<io::SNamedPath&>(texture->getName());
	name.setPath(newName);

	Textures.sort();
}


//! loads a Texture
ITexture* Engine::getTexture(const io::path& filename)
{
	// Identify textures by their absolute filenames if possible.
	const io::path absolutePath = FileSystem->getAbsolutePath(filename);

	///SDL_Log("getTexture %s ",filename.c_str());
	//SDL_Log("getTexture %s ",absolutePath.c_str());


	ITexture* texture = findTexture(absolutePath);
	if (texture)
		return texture;

	//SDL_Log(" Then try the raw filename, which might be in an Archive");
	texture = findTexture(filename);
	if (texture)
		return texture;


//	SDL_Log("Now try to open the file using the complete path.");
	io::IReadFile* file = FileSystem->createAndOpenFile(absolutePath);

	if (!file)
	{
		//SDL_Log(" Try to open it using the raw filename.");
		file = FileSystem->createAndOpenFile(filename);
	}

	if (file)
	{
		//SDL_Log(" Re-check name for actual archive names");
		texture = findTexture(file->getFileName());
		if (texture)
		{
			file->drop();
			return texture;
		}

		texture = loadTextureFromFile(file);
		file->drop();

		if (texture)
		{
			addTexture(texture);
			texture->drop(); // drop it because we created it, one grab too much
		}
		else
			os::Printer::log("Could not load texture", filename, ELL_ERROR);

		return texture;
	}
	else
	{
		os::Printer::log("Could not open file of texture", filename, ELL_WARNING);
		return 0;
	}
}


//! loads a Texture
ITexture* Engine::getTexture(io::IReadFile* file)
{
	ITexture* texture = 0;

	if (file)
	{
		texture = findTexture(file->getFileName());

		if (texture)
			return texture;

		texture = loadTextureFromFile(file);

		if (texture)
		{
			addTexture(texture);
			texture->drop(); // drop it because we created it, one grab too much
		}

		if (!texture)
			os::Printer::log("Could not load texture", file->getFileName(), ELL_WARNING);
	}

	return texture;
}

//! adds a surface, not loaded or created by the Irrlicht Engine
void Engine::addTexture(video::ITexture* texture)
{
	if (texture)
	{
		texture->grab();
		Textures.push_back(texture);
		Textures.sort();
	}
}


//! looks if the image is already loaded
video::ITexture* Engine::findTexture(const io::path& filename)
{


for (u32 i=0; i<Textures.size(); ++i)
{

		 video::ITexture* tex = Textures[i];
		 //SDL_Log("TEXTURES [%d]  %s %s %s",i,tex->getDebugName(),tex->getName().getInternalName().c_str(),tex->getName().getPath().c_str());
         if (tex->getName().getInternalName()==filename)
         {
         //SDL_Log("Find texture  %s ",tex->getName().getPath().c_str());
         return tex;
         }

}

    //SDL_Log("dont find texture  %s ",filename.c_str());

	return 0;
}
//! opens the file and loads it into the surface
video::ITexture* Engine::loadTextureFromFile(io::IReadFile* file, const io::path& hashName )
{
	ITexture* texture = 0;

	//SDL_Log("load texture from fille %s ",hashName.c_str());
	IImage* image = createImageFromFile(file);

	if (image)
	{
		// create texture from surface
        texture = new video::COpenGLTexture(image, hashName.size() ? hashName : file->getFileName() );
        texture->grab();

		//os::Printer::log("Loaded texture", file->getFileName());
		image->drop();
		image=0;
	}

	return texture;
}




//! Creates a software image from a file.
IImage* Engine::createImageFromFile(const io::path& filename)
{
	if (!filename.size())
		return 0;

	IImage* image = 0;
	io::IReadFile* file = FileSystem->createAndOpenFile(filename);

	if (file)
	{
		image = createImageFromFile(file);
		file->drop();
	}
	else
		os::Printer::log("Could not open file of image", filename, ELL_WARNING);

	return image;
}


//! Creates a software image from a file.
IImage* Engine::createImageFromFile(io::IReadFile* file)
{
	if (!file)
		return 0;


	int width,format, height=0;
    file->seek(0);
	u8* input = new u8[file->getSize()];
	file->seek(0);
	file->read(input, file->getSize());
	file->seek(0);
	int len =file->getSize();


  	u8* pixels = stbi_load_from_memory(input, len, &width, &height, &format,  STBI_default);



        int new_width = 1;
		int new_height = 1;
		while( new_width < width )
		{
			new_width *= 2;
		}
		while( new_height < height )
		{
			new_height *= 2;
		}

		if( (new_width != width) || (new_height != height) )
		{

		    u8 *resampled = (unsigned char*)malloc( format*new_width*new_height );
			up_scale_image(pixels, width, height, format,resampled, new_width, new_height );

			free( (u8*)pixels );
			pixels = resampled;
			width = new_width;
			height = new_height;
			//printf("resample  w:%i h:%i c:%i \n",width,height,channels);
			os::Printer::log("Resample image .",file->getFileName(), ELL_INFORMATION);
		}


printf("LOAD PNG:  %s  size:%d  (%d %d)  format:%d \n",file->getFileName().c_str(), len,width,height,format, ELL_ERROR);

video::IImage* image = 0;



	if (format==4)
	{

		image = new CImage(ECF_A8R8G8B8, core::dimension2d<u32>(width, height),(u8*)pixels);
    }
	else if (format==3)
	{

		image = new CImage(ECF_R8G8B8, core::dimension2d<u32>(width, height),(u8*)pixels);

    } else
    {

           u8 *resampled   = (u8*)malloc( 4 * width * height*sizeof(u8) );
           core::quaternion *PIXELS = core::LoadPixelDataNormalized(pixels,width,height,format);     // Supports 8 to 32 bit per channel

                    for (int i = 0, k = 0; i < width*height*4; i += 4, k++)
                    {
                        ((u8*)resampled)[i + 0] = (u8)(PIXELS[k].X*255.0f);
                        ((u8*)resampled)[i + 1] = (u8)(PIXELS[k].Y*255.0f);
                        ((u8*)resampled)[i + 2] = (u8)(PIXELS[k].Z*255.0f);
                        ((u8*)resampled)[i + 3] = (u8)(PIXELS[k].W*255.0f);



                    }

      free(pixels);
      image = new CImage(ECF_A8R8G8B8, core::dimension2d<u32>(width, height),(u8*)resampled);

    }




//	if (input)	delete [] input;



	if (!image)
	{
		os::Printer::log("LOAD PNG: Internal PNG create image struct failure", file->getFileName(), ELL_ERROR);
		return 0;
	}



	return image;
}


//! Writes the provided image to disk file
bool Engine::writeImageToFile(IImage* image, const io::path& filename)
{
	io::IWriteFile* file = FileSystem->createAndWriteFile(filename);
	if(!file)
		return false;

	bool result = writeImageToFile(image, file);
	file->drop();

	return result;
}

//! Writes the provided image to a file.
bool Engine::writeImageToFile(IImage* image, io::IWriteFile * file)
{
	if(!file)
		return false;

SDL_Log("save %s ",file->getFileName().c_str());

u32 pixel_size = image->getBytesPerPixel();
u32 row_stride = (pixel_size * image->getDimension().Width);
stbi_write_png(file->getFileName().c_str(),image->getDimension().Width,image->getDimension().Height,4,image->getData(),image->getImageDataSizeInBytes());

	return true;
}


//! Creates a software image from a byte array.
IImage* Engine::createImageFromData(ECOLOR_FORMAT format,
					const core::dimension2d<u32>& size,
					void *data, bool ownForeignMemory,
					bool deleteMemory)
{

	return new CImage(format, size, data, ownForeignMemory, deleteMemory);
}


//! Creates an empty software image.
IImage* Engine::createImage(ECOLOR_FORMAT format, const core::dimension2d<u32>& size)
{

	return new CImage(format, size);
}





//! Creates a software image from part of a texture.
IImage* Engine::createImage(ITexture* texture, const core::position2d<s32>& pos, const core::dimension2d<u32>& size)
{
/*	if ((pos==core::position2di(0,0)) && (size == texture->getSize()))
	{
		IImage* image = new CImage(texture->getColorFormat(), size, texture->lock(ETLM_READ_ONLY), false);
		texture->unlock();
		return image;
	}
	else
	{
		// make sure to avoid buffer overruns
		// make the vector a separate variable for g++ 3.x
		const core::vector2d<u32> leftUpper(core::clamp(static_cast<u32>(pos.X), 0u, texture->getSize().Width),
					core::clamp(static_cast<u32>(pos.Y), 0u, texture->getSize().Height));
		const core::rect<u32> clamped(leftUpper,
					core::dimension2du(core::clamp(static_cast<u32>(size.Width), 0u, texture->getSize().Width),
					core::clamp(static_cast<u32>(size.Height), 0u, texture->getSize().Height)));
		if (!clamped.isValid())
			return 0;
		u8* src = static_cast<u8*>(texture->lock(ETLM_READ_ONLY));
		if (!src)
			return 0;
		IImage* image = new CImage(texture->getColorFormat(), clamped.getSize());
		u8* dst = static_cast<u8*>(image->lock());
		src += clamped.UpperLeftCorner.Y * texture->getPitch() + image->getBytesPerPixel() * clamped.UpperLeftCorner.X;
		for (u32 i=0; i<clamped.getHeight(); ++i)
		{
			video::CColorConverter::convert_viaFormat(src, texture->getColorFormat(), clamped.getWidth(), dst, image->getColorFormat());
			src += texture->getPitch();
			dst += image->getPitch();
		}
		image->unlock();
		texture->unlock();
		return image;
	}*/
}

void Engine::setAlphaFunc(GLenum mode, GLclampf ref)
{
if (AlphaMode != mode || AlphaRef != ref)
	{
//		glAlphaFunc(mode, ref);

		AlphaMode = mode;
		AlphaRef = ref;
	}

}


IShader* Engine::loadShaderFromFile(const char* vertexPath, const char* fragmentPath,const char* ID)
{
    IShader* shader= new IShader(vertexPath,fragmentPath,true);
    Shaders.insert(ID,shader);
    return shader;
}

IShader* Engine::loadShader(const char* vertexPath, const char* fragmentPath,const char* ID)
{
    IShader* shader=new IShader(vertexPath,fragmentPath,false);
    Shaders.insert(ID,shader);
    return shader;
}
void Engine::setShader(IShader* shader)
{
   if(shader)
   {
     setProgram(shader->ID);
   }
}
IShader* Engine::setShader(const char* ID)
{
   IShader* shader =getShader(ID);
   if(shader)
   {
     setProgram(shader->ID);

   }
   return shader;
}
IShader* Engine::getShader(const char* ID)
{
core::map<const char*, IShader*>::Node* n= Shaders.find(ID);
if(n)
{
 return n->getValue();
}

SDL_Log("[SHADER] Fail find shader %s ",ID);
return 0;
}


}
}
