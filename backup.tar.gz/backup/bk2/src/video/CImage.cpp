// Copyright (C) 2002-2012 Nikolaus Gebhardt / Thomas Alten
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in irrlicht.h

#include "CImage.h"
#include "irrString.h"
#include "CColorConverter.h"
#include "CBlit.h"
#include "os.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

namespace irr
{
namespace video
{

CImage::CImage()
{
}
//! Constructor from raw data
CImage::CImage(ECOLOR_FORMAT format, const core::dimension2d<u32>& size, void* data,
	bool ownForeignMemory, bool deleteMemory) : IImage(format, size, deleteMemory)
{

    BytesPerPixel = getBitsPerPixelFromFormat(Format) / 8;
	Pitch = BytesPerPixel * Size.Width;

	if (!Data)
	{
		DeleteMemory=true;
		Data = new u8[Size.Height * Pitch];
	}

	if (ownForeignMemory)
	{
		Data = (u8*)data;
	}
	else
	{
		const u32 dataSize = getDataSizeFromFormat(Format, Size.Width, Size.Height);
		Data = new u8[align_next(dataSize,16)];
		memcpy(Data, data, dataSize);
		DeleteMemory = true;
	}
}
//! Constructor of empty image
CImage::CImage(ECOLOR_FORMAT format, const core::dimension2d<u32>& size) : IImage(format, size, true)
{
    BytesPerPixel = getBitsPerPixelFromFormat(Format) / 8;
	Pitch = BytesPerPixel * Size.Width;
	Data = new u8[align_next(getDataSizeFromFormat(Format, Size.Width, Size.Height),16)];
	DeleteMemory = true;
}

int CImage::GetPixelDataSize(int width, int height, ECOLOR_FORMAT format)
{
    int dataSize = 0;       // Size in bytes
    int bpp = 0;            // Bits per pixel

    switch (format)
    {
        //case 1: bpp = 8; break;
        //case 2: bpp = 8; break;
        case video::ECF_R8G8B8  : bpp = 24; break;
        case video::ECF_A8R8G8B8: bpp = 32; break;
        default: break;
    }

    dataSize = width*height*bpp/8;  // Total data size in bytes


    return dataSize;
}
CImage::CImage(const char* FileName,bool invert)
{
int   Width, Height,channels;
unsigned int  original_texture_format = 0;
unsigned int fileSize = 0;
unsigned char *fileData = irr::core::LoadFileData(FileName, &fileSize);
if (fileData != NULL)
{
stbi_set_flip_vertically_on_load(invert);
Data= stbi_load_from_memory(fileData, fileSize, &Width,  &Height,  &channels,0);
} else
{
SDL_Log("IMAGE: [%s] Failed to load image. \n", FileName);
}

if (Data)
{

Size.Width =Width;
Size.Height=Height;



    if (channels==4)
    {
    	Format=video::ECF_A8R8G8B8;
    }

	else if (channels==3)
	{
		Format=video::ECF_R8G8B8;
    } else{

    	Format=video::ECF_A8R8G8B8;

           u8 *resampled   = (u8*)malloc( 4 * Width * Height*sizeof(u8) );
           core::quaternion *PIXELS = core::LoadPixelDataNormalized(Data,Width,Height,channels);     // Supports 8 to 32 bit per channel

                    for (int i = 0, k = 0; i < Width*Height*4; i += 4, k++)
                    {
                        ((u8*)resampled)[i + 0] = (u8)(PIXELS[k].X*255.0f);
                        ((u8*)resampled)[i + 1] = (u8)(PIXELS[k].Y*255.0f);
                        ((u8*)resampled)[i + 2] = (u8)(PIXELS[k].Z*255.0f);
                        ((u8*)resampled)[i + 3] = (u8)(PIXELS[k].W*255.0f);



                    }

      free(Data);
      Data=resampled;



    }




    BytesPerPixel = getBitsPerPixelFromFormat(Format) / 8;
    Pitch = BytesPerPixel * Size.Width;
    const u32 dataSize = getDataSizeFromFormat(Format, Size.Width, Size.Height);
	DeleteMemory = true;


	 SDL_Log("IMAGE  Load  size(%d)   channels(%d)  BPP(%d) Pitch(%d) ", dataSize, channels,BytesPerPixel,Pitch);








}else{
	   SDL_Log("IMAGE: [%s] Failed to load image. \n", FileName);

}



}

bool CImage::Save(const char* FileName)
{
u32 pixel_size = getBytesPerPixel();
u32 row_stride = (pixel_size * getDimension().Width);


	int channels=0;
	switch(Format)
		{
		case ECF_A1R5G5B5:
			channels=4;break;
		case ECF_R5G6B5:
			channels=3;break;
		case ECF_R8G8B8:
			channels=3;break;
		case ECF_A8R8G8B8:
			channels=4;break;
        }




if (irr::core::IsFileWithExtension(FileName,"png"))
{
stbi_write_png(FileName,(int)getDimension().Width, (int)getDimension().Height,channels,Data,row_stride);
} else
if (irr::core::IsFileWithExtension(FileName,"jpeg"))
{
 stbi_write_jpg(FileName,(int)getDimension().Width, (int)getDimension().Height,channels,Data,90);
} else
if (irr::core::IsFileWithExtension(FileName,"bmp"))
{

 stbi_write_bmp(FileName,(int)getDimension().Width, (int)getDimension().Height,channels,Data);
}else
if (irr::core::IsFileWithExtension(FileName,"tga"))
{

 stbi_write_tga(FileName,(int)getDimension().Width, (int)getDimension().Height,channels,Data);
}






}




//! sets a pixel
void CImage::setPixel(u32 x, u32 y, const SColor &color, bool blend)
{
	if (x >= Size.Width || y >= Size.Height)
		return;

	switch(Format)
	{
		case ECF_A1R5G5B5:
		{
			u16 * dest = (u16*) (Data + ( y * Pitch ) + ( x << 1 ));
			*dest = video::A8R8G8B8toA1R5G5B5( color.color );
		} break;

		case ECF_R5G6B5:
		{
			u16 * dest = (u16*) (Data + ( y * Pitch ) + ( x << 1 ));
			*dest = video::A8R8G8B8toR5G6B5( color.color );
		} break;

		case ECF_R8G8B8:
		{
			u8* dest = Data + ( y * Pitch ) + ( x * 3 );
			dest[0] = (u8)color.getRed();
			dest[1] = (u8)color.getGreen();
			dest[2] = (u8)color.getBlue();
		} break;

		case ECF_A8R8G8B8:
		{
			u32 * dest = (u32*) (Data + ( y * Pitch ) + ( x << 2 ));
			*dest = blend ? PixelBlend32 ( *dest, color.color ) : color.color;
		} break;

		case ECF_UNKNOWN:
			os::Printer::log("IImage::setPixel unknown format.", ELL_WARNING);
			return;

		default:
			break;
	}
}


//! returns a pixel
SColor CImage::getPixel(u32 x, u32 y) const
{
	if (x >= Size.Width || y >= Size.Height)
		return SColor(0);

	switch(Format)
	{
	case ECF_A1R5G5B5:
		return A1R5G5B5toA8R8G8B8(((u16*)Data)[y*Size.Width + x]);
	case ECF_R5G6B5:
		return R5G6B5toA8R8G8B8(((u16*)Data)[y*Size.Width + x]);
	case ECF_A8R8G8B8:
		return ((u32*)Data)[y*Size.Width + x];
	case ECF_R8G8B8:
		{
			u8* p = Data+(y*3)*Size.Width + (x*3);
			return SColor(255,p[0],p[1],p[2]);
		}
	case ECF_UNKNOWN:
		os::Printer::log("IImage::getPixel unknown format.", ELL_WARNING);
		break;

	default:
		break;
	}

	return SColor(0);
}


//! copies this surface into another at given position
void CImage::copyTo(IImage* target, const core::position2d<s32>& pos)
{


	if (!Blit(BLITTER_TEXTURE, target, 0, &pos, this, 0, 0)
		&& target && pos.X == 0 && pos.Y == 0 &&
		CColorConverter::canConvertFormat(Format, target->getColorFormat()))
	{
		// No fast blitting, but copyToScaling uses other color conversions and might work
		irr::core::dimension2du dim(target->getDimension());
		copyToScaling(target->getData(), dim.Width, dim.Height, target->getColorFormat(), target->getPitch());
	}
}


//! copies this surface partially into another at given position
void CImage::copyTo(IImage* target, const core::position2d<s32>& pos, const core::rect<s32>& sourceRect, const core::rect<s32>* clipRect)
{


	Blit(BLITTER_TEXTURE, target, clipRect, &pos, this, &sourceRect, 0);
}


//! copies this surface into another, using the alpha mask, a cliprect and a color to add with
void CImage::copyToWithAlpha(IImage* target, const core::position2d<s32>& pos, const core::rect<s32>& sourceRect, const SColor &color, const core::rect<s32>* clipRect, bool combineAlpha)
{
	eBlitter op = combineAlpha ? BLITTER_TEXTURE_COMBINE_ALPHA :
		color.color == 0xFFFFFFFF ? BLITTER_TEXTURE_ALPHA_BLEND : BLITTER_TEXTURE_ALPHA_COLOR_BLEND;
	Blit(op,target, clipRect, &pos, this, &sourceRect, color.color);
}


//! copies this surface into another, scaling it to the target image size
// note: this is very very slow.
void CImage::copyToScaling(void* target, u32 width, u32 height, ECOLOR_FORMAT format, u32 pitch)
{


	if (!target || !width || !height)
		return;

	const u32 bpp=getBitsPerPixelFromFormat(format)/8;
	if (0==pitch)
		pitch = width*bpp;

	if (Format==format && Size.Width==width && Size.Height==height)
	{
		if (pitch==Pitch)
		{
			memcpy(target, Data, height*pitch);
			return;
		}
		else
		{
			u8* tgtpos = (u8*) target;
			u8* srcpos = Data;
			const u32 bwidth = width*bpp;
			const u32 rest = pitch-bwidth;
			for (u32 y=0; y<height; ++y)
			{
				// copy scanline
				memcpy(tgtpos, srcpos, bwidth);
				// clear pitch
				memset(tgtpos+bwidth, 0, rest);
				tgtpos += pitch;
				srcpos += Pitch;
			}
			return;
		}
	}

	// NOTE: Scaling is coded to keep the border pixels intact.
	// Alternatively we could for example work with first pixel being taken at half step-size.
	// Then we have one more step here and it would be:
	//     sourceXStep = (f32)(Size.Width-1) / (f32)(width);
	//     And sx would start at 0.5f + sourceXStep / 2.f;
	//     Similar for y.
	// As scaling is done without any antialiasing it doesn't matter too much which outermost pixels we use and keeping
	// border pixels intact is probably mostly better (with AA the other solution would be more correct).
	const f32 sourceXStep = width > 1 ? (f32)(Size.Width-1) / (f32)(width-1) : 0.f;
	const f32 sourceYStep = height > 1 ? (f32)(Size.Height-1) / (f32)(height-1) : 0.f;
	s32 yval=0, syval=0;
	f32 sy = 0.5f;	// for rounding to nearest pixel
	for (u32 y=0; y<height; ++y)
	{
		f32 sx = 0.5f;	// for rounding to nearest pixel
		for (u32 x=0; x<width; ++x)
		{
			CColorConverter::convert_viaFormat(Data+ syval + ((s32)sx)*BytesPerPixel, Format, 1, ((u8*)target)+ yval + (x*bpp), format);
			sx+=sourceXStep;
		}
		sy+=sourceYStep;
		syval=(s32)(sy)*Pitch;
		yval+=pitch;
	}
}


//! copies this surface into another, scaling it to the target image size
// note: this is very very slow.
void CImage::copyToScaling(IImage* target)
{

	if (!target)
		return;

	const core::dimension2d<u32>& targetSize = target->getDimension();

	if (targetSize==Size)
	{
		copyTo(target);
		return;
	}

	copyToScaling(target->getData(), targetSize.Width, targetSize.Height, target->getColorFormat());
}


//! copies this surface into another, scaling it to fit it.
void CImage::copyToScalingBoxFilter(IImage* target, s32 bias, bool blend)
{


	const core::dimension2d<u32> destSize = target->getDimension();

	const f32 sourceXStep = (f32) Size.Width / (f32) destSize.Width;
	const f32 sourceYStep = (f32) Size.Height / (f32) destSize.Height;

	target->getData();

	s32 fx = core::ceil32( sourceXStep );
	s32 fy = core::ceil32( sourceYStep );
	f32 sx;
	f32 sy;

	sy = 0.f;
	for ( u32 y = 0; y != destSize.Height; ++y )
	{
		sx = 0.f;
		for ( u32 x = 0; x != destSize.Width; ++x )
		{
			target->setPixel( x, y,
				getPixelBox( core::floor32(sx), core::floor32(sy), fx, fy, bias ), blend );
			sx += sourceXStep;
		}
		sy += sourceYStep;
	}
}


//! fills the surface with given color
void CImage::fill(const SColor &color)
{

	u32 c;

	switch ( Format )
	{
		case ECF_A1R5G5B5:
			c = color.toA1R5G5B5();
			c |= c << 16;
			break;
		case ECF_R5G6B5:
			c = video::A8R8G8B8toR5G6B5( color.color );
			c |= c << 16;
			break;
		case ECF_A8R8G8B8:
			c = color.color;
			break;
		case ECF_R8G8B8:
		{
			u8 rgb[3];
			CColorConverter::convert_A8R8G8B8toR8G8B8(&color, 1, rgb);
			const u32 size = getImageDataSizeInBytes();
			for (u32 i=0; i<size; i+=3)
			{
				memcpy(Data+i, rgb, 3);
			}
			return;
		}
		break;
		default:
		// TODO: Handle other formats
			return;
	}
	memset32( Data, c, getImageDataSizeInBytes() );
}


//! get a filtered pixel
inline SColor CImage::getPixelBox( s32 x, s32 y, s32 fx, s32 fy, s32 bias ) const
{


	SColor c;
	s32 a = 0, r = 0, g = 0, b = 0;

	for ( s32 dx = 0; dx != fx; ++dx )
	{
		for ( s32 dy = 0; dy != fy; ++dy )
		{
			c = getPixel(	core::s32_min ( x + dx, Size.Width - 1 ) ,
							core::s32_min ( y + dy, Size.Height - 1 )
						);

			a += c.getAlpha();
			r += c.getRed();
			g += c.getGreen();
			b += c.getBlue();
		}

	}

	s32 sdiv = s32_log2_s32(fx * fy);

	a = core::s32_clamp( ( a >> sdiv ) + bias, 0, 255 );
	r = core::s32_clamp( ( r >> sdiv ) + bias, 0, 255 );
	g = core::s32_clamp( ( g >> sdiv ) + bias, 0, 255 );
	b = core::s32_clamp( ( b >> sdiv ) + bias, 0, 255 );

	c.set( a, r, g, b );

	return c;
}
void CImage::FlipVertical()
{
u32 pixel_size = getBytesPerPixel();
u32 row_stride = (pixel_size * getDimension().Width);


	int channels=0;
	switch(Format)
		{
		case ECF_A1R5G5B5:
			channels=4;break;
		case ECF_R5G6B5:
			channels=3;break;
		case ECF_R8G8B8:
			channels=3;break;
		case ECF_A8R8G8B8:
			channels=4;break;
        }

        int bytesPerPixel =channels;// GetPixelDataSize(1, 1, image->format);
        unsigned char *flippedData = (u8 *)malloc(Size.Width*Size.Height*bytesPerPixel);

        for (int i = (Size.Height - 1), offsetSize = 0; i >= 0; i--)
        {
            memcpy(flippedData + offsetSize, ((u8 *)Data) + i*Size.Width*bytesPerPixel, Size.Width*bytesPerPixel);
            offsetSize += Size.Width*bytesPerPixel;
        }

        free(Data);
        Data = flippedData;

}

void CImage::FlipHorizontal()
{
        uint32_t *ptr = (uint32_t *)Data;
        for (int y = 0; y < Size.Height; y++)
        {
            for (int x = 0; x < Size.Width/2; x++)
            {
                uint32_t backup = ptr[y*Size.Width + x];
                ptr[y*Size.Width + x] = ptr[y*Size.Width + (Size.Width - 1 - x)];
                ptr[y*Size.Width + (Size.Width - 1 - x)] = backup;
            }
        }

}


} // end namespace video
} // end namespace irr
