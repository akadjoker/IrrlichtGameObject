#ifndef ENGINE_H
#define ENGINE_H


#include "CImage.h"
#include "CShader.h"
#include "COpenGLTexture.h"
#include "CGeometryCreator.h"


#include "os.h"
#include "IrrCompileConfig.h"
#include "aabbox3d.h"
#include "CDynamicMeshBuffer.h"
#include "CIndexBuffer.h"
#include "CMeshBuffer.h"
#include "coreutil.h"
#include "CVertexBuffer.h"

#include "dimension2d.h"
#include "IEngineEnums.h"


#include "fast_atof.h"
#include "heapsort.h"
#include "IAnimatedMesh.h"
#include "IDynamicMeshBuffer.h"
#include "IFileList.h"
#include "IFileSystem.h"
#include "CFileSystem.h"
#include "IGeometryCreator.h"
#include "IImage.h"
#include "IIndexBuffer.h"
#include "ILogger.h"
#include "IMesh.h"
#include "IMeshBuffer.h"
#include "IMeshLoader.h"
#include "IMeshManipulator.h"
#include "IMeshWriter.h"

#include "IReadFile.h"
#include "IReferenceCounted.h"
#include "irrArray.h"
#include "IRandomizer.h"
#include "irrList.h"
#include "irrMap.h"
#include "irrMath.h"
#include "irrString.h"
#include "irrTypes.h"
#include "path.h"
#include "irrXML.h"
#include "ISkinnedMesh.h"
#include "ITexture.h"
#include "ITimer.h"
#include "IVertexBuffer.h"
#include "IWriteFile.h"
#include "IXMLReader.h"
#include "IXMLWriter.h"
#include "line2d.h"
#include "line3d.h"
#include "matrix4.h"
#include "plane3d.h"
#include "position2d.h"
#include "quaternion.h"
#include "rect.h"
#include "S3DVertex.h"
#include "SAnimatedMesh.h"
#include "SColor.h"
#include "SMaterial.h"
#include "SMesh.h"
#include "SSharedMeshBuffer.h"
#include "SSkinMeshBuffer.h"
#include "SViewFrustum.h"
#include "triangle3d.h"
#include "vector2d.h"
#include "vector3d.h"
#include "CWriteFile.h"

namespace irr
{

void ShowSimpleMessageBox(Uint32 flags, const char *title, const char *message);
namespace scene
{

using namespace  video;
using namespace io;



class Engine : public  IReferenceCounted
{
    public:
        Engine(int width, int heigth);
        virtual ~Engine();

    static Engine* Instance();

    static Engine* createEngine(int w,int h);




    ITexture* getTexture(const char* FileName,const char* name);

    double GetTime(void);
    float GetFrameTime(void);
    void SetTargetFPS(int fps);
    int GetFPS(void);
    void Wait(float ms);

    void ClearScene(u16 clearFlag, SColor color = SColor(255,0,0,45), f32 depth = 1.f, u8 stencil = 0);
    void BeginScene();
    void EndScene();

    void renderMesh(IMesh* mesh);
    void renderMeshBuffer(IMeshBuffer* meshBuffer);


    void setAlphaFunc(GLenum mode, GLclampf ref);
    void setAlphaTest(bool enable);


    void setBasicRenderStates(const SMaterial& material, const SMaterial& lastmaterial, bool resetAllRenderStates);
    void setTextureRenderStates(const SMaterial& material, bool resetAllRenderstates);





    void setBlendEquation(GLenum mode);
	void setBlendFunc(GLenum source, GLenum destination);
	void setBlendFuncSeparate(GLenum sourceRGB, GLenum destinationRGB, GLenum sourceAlpha, GLenum destinationAlpha);
	void setBlend(bool enable);

	void setStencilTest(bool enable);
	void startStencilTest();
	void endStencilTest();
	// Color Mask.

	void getColorMask(u8& mask);
	void setColorMask(u8 mask);

	// Cull face calls.

	void setCullFaceFunc(GLenum mode);
	void setCullFace(bool enable);
	// Depth calls.

	void setDepthFunc(GLenum mode);
	void getDepthMask(bool& depth);
	void setDepthMask(bool enable);
    void getDepthTest(bool& enable);
	void setDepthTest(bool enable);


	// FBO calls.

	void getFBO(GLuint& frameBufferID) const;

	void setFBO(GLuint frameBufferID);

	// Shaders calls.

	void getProgram(GLuint& programID) const;

	void setProgram(GLuint programID);

	// Texture calls.

	void getActiveTexture(GLenum& texture) const;
	void setActiveTexture(GLenum texture);
	void setTexture(GLuint type,GLuint texture);
	void setTexture(const video::ITexture* texture,int layer);
	void setTexture(const video::ITexture* texture);

	// Viewport calls.

	void getViewport(GLint& viewportX, GLint& viewportY, GLsizei& viewportWidth, GLsizei& viewportHeight) const;
	void setViewport(GLint viewportX, GLint viewportY, GLsizei viewportWidth, GLsizei viewportHeight);



	IFileSystem*      getFileSystem(){return FileSystem;};
    IMeshManipulator* getMeshManipulator(){return MeshManipulator;};
    IGeometryCreator* getGeometryCreator(){return GeometryCreator;};



		bool getWriteZBuffer(const SMaterial& material) const
		{
		return 	 material.ZWriteEnable && !material.isTransparent();
		}
		GLenum getGLBlend(E_BLEND_FACTOR factor) const
	{
		static GLenum const blendTable[] =
		{
			GL_ZERO,
			GL_ONE,
			GL_DST_COLOR,
			GL_ONE_MINUS_DST_COLOR,
			GL_SRC_COLOR,
			GL_ONE_MINUS_SRC_COLOR,
			GL_SRC_ALPHA,
			GL_ONE_MINUS_SRC_ALPHA,
			GL_DST_ALPHA,
			GL_ONE_MINUS_DST_ALPHA,
			GL_SRC_ALPHA_SATURATE
		};

		return blendTable[factor];
	}

	GLenum getZBufferBits() const;
	GLint getTextureWrapMode(u8 clamp) const;

    void setMaterial(const SMaterial& material);

    //! deletes all textures
		void deleteAllTextures();

		//! opens the file and loads it into the surface
		video::ITexture* loadTextureFromFile(io::IReadFile* file, const io::path& hashName = "");


		//! adds a surface, not loaded or created by the Irrlicht Engine
		void addTexture(video::ITexture* surface);

		//! looks if the image is already loaded
		 video::ITexture* findTexture(const io::path& filename);
		//! Removes a texture from the texture cache and deletes it, freeing lot of
		//! memory.
		 void removeTexture(ITexture* texture);

		//! Removes all texture from the texture cache and deletes them, freeing lot of
		//! memory.
		 void removeAllTextures();



		 void drawStencilShadow(bool clearStencilBuffer=true);




		//! loads a Texture
		 ITexture* getTexture(const io::path& filename);

		//! loads a Texture
		 ITexture* getTexture(io::IReadFile* file);

		//! Returns a texture by index
		 ITexture* getTextureByIndex(u32 index);

		//! Returns amount of textures currently loaded
		 u32 getTextureCount() const;

		//! Renames a texture
		 void renameTexture(ITexture* texture, const io::path& newName);

		 		//! Creates a software image from a file.
		 IImage* createImageFromFile(const io::path& filename);

		//! Creates a software image from a file.
		 IImage* createImageFromFile(io::IReadFile* file);

		  IImage* createImageFromData(ECOLOR_FORMAT format,
			const core::dimension2d<u32>& size, void *data,
			bool ownForeignMemory=true, bool deleteForeignMemory = true);

		//! Creates an empty software image.
		 IImage* createImage(ECOLOR_FORMAT format, const core::dimension2d<u32>& size);

		 IImage* createImage(ITexture* texture, const core::position2d<s32>& pos, const core::dimension2d<u32>& size);


        bool writeImageToFile(IImage* image, const io::path& filename);
        bool writeImageToFile(IImage* image, io::IWriteFile * file);


        IShader* loadShaderFromFile(const char* vertexPath, const char* fragmentPath,const char* ID);
        IShader* loadShader(const char* vertexPath, const char* fragmentPath,const char* ID);
        IShader* getShader(const char* ID);
        void setShader(IShader* shader);
        IShader* setShader(const char* ID);




    protected:


    private:

    IFileSystem      *FileSystem;
    IMeshManipulator *MeshManipulator;
    IGeometryCreator *GeometryCreator;

    double current;                     // Current time measure
	double previous;                    // Previous time measure
	double update;                      // Time measure for frame update
	double draw;                        // Time measure for frame draw
	double frame;                       // Time measure for one frame
	double target;                      // Desired time for one frame, if 0 not applied

	//gl states
			float DimAliasedLine[2];
			float DimAliasedPoint[2];
    	GLenum AlphaMode;
		GLclampf AlphaRef;
		bool AlphaTest;
		GLenum MatrixMode;
		GLenum ClientActiveTexture;




	GLuint FrameBufferCount;

	GLenum* BlendEquation;
	GLenum* BlendSourceRGB;
	GLenum* BlendDestinationRGB;
	GLenum* BlendSourceAlpha;
	GLenum* BlendDestinationAlpha;
	bool* Blend;
	bool BlendEquationInvalid;
	bool BlendFuncInvalid;
	bool BlendInvalid;


	u8* ColorMask;
	bool ColorMaskInvalid;

	GLenum CullFaceMode;
	bool CullFace;

	GLenum DepthFunc;
	bool DepthMask;
	bool DepthTest;
	bool StencilTest;
    u8 MaxAnisotropicFilter;

	GLuint FrameBufferID;

	GLuint ProgramID;

	GLenum ActiveTexture;
	GLenum CurrTexture;
	SMaterial currMaterial,LastMaterial;

	GLint ViewportX;
	GLint ViewportY;
	GLsizei ViewportWidth;
	GLsizei ViewportHeight;

    core::array<ITexture*> Textures;
    //core::array<IShader*>  Shaders;
    core::map<const char*,IShader*>  Shaders;
    IShader* currentShader;

    GLuint stencil_vbo;
    int	midStencilVal;

    //core::map<irr::core::stringc, bool> MaterialsWritten;


};
}
}
#endif // ENGINE_H
