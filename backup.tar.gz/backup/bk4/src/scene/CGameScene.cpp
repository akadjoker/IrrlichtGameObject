
#include "Engine.h"
#include "CGameScene.h"


namespace irr
{
namespace scene
{

CGameScene::CGameScene(core::stringc name,s32 id):IGameScene(name,id),ShadowColor(150,0,0,0), AmbientLight(0,0,0,0)
{
  setDebugName("CGameScene");
 // SDL_Log("Create CScnene %s %d",Name.c_str(),ID);
}

CGameScene::~CGameScene()
{
  // SDL_Log("[SCENE] Delete %s %d",Name.c_str(),ID);
   removeAll();

}

void CGameScene::OnUpdate(u32 timeMs)
{
IGameObjectList::Iterator it = GameObjectList.begin();

for (; it != GameObjectList.end(); ++it)
    (*it)->OnUpdate(timeMs);
}

void CGameScene::OnRender(IShader* shader)
{
scene::Engine::Instance()->setMaterial(video::SMaterial());

IGameObjectList::Iterator it = GameObjectList.begin();
for (; it != GameObjectList.end(); ++it)
    (*it)->OnRender(shader);
}

IGameObject* CGameScene::createGameObject(core::stringc name)
{
   IGameObject* gameObject = new IGameObject();
   gameObject->setName(name.c_str());
   GameObjectList.push_back(gameObject);
   return gameObject;
}
IGameObject* CGameScene::createGameObject(core::stringc name,s32 id)
{
   IGameObject* gameObject = new IGameObject();
   gameObject->setName(name.c_str());
   gameObject->setID(id);

   GameObjectList.push_back(gameObject);
   return gameObject;
}
IGameObject* CGameScene::createGameObject(IGameObject* parent, s32 id,core::stringc name)
{
  IGameObject* gameObject = new IGameObject();
   gameObject->setName(name.c_str());
   gameObject->setID(id);
 if(parent)  gameObject->setParent(parent);
//   GameObjectList.push_back(gameObject);
   return gameObject;
}


IGameObject* CGameScene::createGameObject(IGameObject* parent, s32 id)
{
  IGameObject* gameObject = new IGameObject();
   gameObject->setID(id);
 if(parent)  gameObject->setParent(parent);
//   GameObjectList.push_back(gameObject);
   return gameObject;
}

IGameObject* CGameScene::createGameObject(IGameObject* parent)
{
  IGameObject* gameObject = new IGameObject();
  if(parent) gameObject->setParent(parent);
 //  GameObjectList.push_back(gameObject);
   return gameObject;
}

IGameObject* CGameScene::createGameObject()
{
   IGameObject* gameObject = new IGameObject();
   GameObjectList.push_back(gameObject);
   return gameObject;
}

IGameObject* CGameScene::addGameObject(IGameObject* gameObject)
{
   GameObjectList.push_back(gameObject);
   return gameObject;
}


IGameObject* CGameScene::removeGameObjectById(s32 id)
{

}

IGameObject* CGameScene::removeGameObjectByName(const core::stringc name)
{

}
IGameObject* CGameScene::getGameObjectById(s32 id)
{
	IGameObject* node = 0;
	const IGameObjectList& list = GameObjectList;
	IGameObjectList::ConstIterator it = list.begin();
	for (; it!=list.end(); ++it)
	{

		IGameObject* n = (IGameObject*)*it;
		if (n)
		{
			if (n->getID()==id)
            {
            return n;
            }
		}

	}

return node;
}

IGameObject* CGameScene::getGameObjectByName(const core::stringc name)
{
	IGameObject* node = 0;


	const IGameObjectList& list = GameObjectList;
	IGameObjectList::ConstIterator it = list.begin();
	for (; it!=list.end(); ++it)
	{

		node = (IGameObject*)*it;
		if (node)
		{
			    //SDL_Log("%d %s %s",strcmp(node->getName(),name.c_str()),node->getName(),name.c_str());
                if (strcmp(node->getName(),name.c_str())==0)
                {
                 return node;
                }
		}

	}

	return node;
}
void CGameScene::removeAll()
{

      //  SDL_Log("Delete Objects");
        IGameObjectList::Iterator it = GameObjectList.begin();
		for (; it != GameObjectList.end(); ++it)
				(*it)->drop();
			GameObjectList.clear();


}

} // end namespace scene
} // end namespace irr



