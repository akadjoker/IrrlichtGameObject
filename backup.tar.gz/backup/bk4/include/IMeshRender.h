#ifndef __I_MESHRENDER_H_INCLUDED
#define __I_MESHRENDER_H_INCLUDED


namespace irr
{
namespace video
{

class IMeshRender : public IMeshRender
{
public:

    IMeshRender(){};
    ~IMeshRender(){};
private:

}
} // end namespace video
} // end namespace irr

#endif
