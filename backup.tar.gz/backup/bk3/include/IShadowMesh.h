#ifndef ISHADOWMESH_H
#define ISHADOWMESH_H

#include <functional>

#include "IMesh.h"
#include "CMeshBuffer.h"
#include "IMeshBuffer.h"

#include "os.h"
#include "IrrCompileConfig.h"
#include "aabbox3d.h"
#include "CIndexBuffer.h"
#include "CMeshBuffer.h"
#include "coreutil.h"
#include "CVertexBuffer.h"

#include "dimension2d.h"

#include "IReferenceCounted.h"

#include "ITexture.h"

#include "line2d.h"
#include "line3d.h"
#include "matrix4.h"
#include "plane3d.h"
#include "position2d.h"
#include "quaternion.h"
#include "rect.h"
#include "S3DVertex.h"
#include "SColor.h"
#include "SMaterial.h"
#include "triangle3d.h"
#include "vector2d.h"
#include "vector3d.h"


namespace irr
{


namespace scene
{
	enum ESHADOWVOLUME_OPTIMIZATION
	{
		//! Create volumes around every triangle
		ESV_NONE,

		//! Create volumes only around the silhouette of the mesh
		/** This can reduce the number of volumes drastically,
		but will have an upfront-cost where it calculates adjacency of
		triangles. Also it will not work with all models. Basically
		if you see strange black shadow lines then you have a model
		for which it won't work.
		We get that information about adjacency by comparing the positions of
		all edges in the mesh (even if they are in different meshbuffers). */
		ESV_SILHOUETTE_BY_POS
	};

class IShadowMesh : public  IReferenceCounted
{
    public:
        IShadowMesh(const scene::IMesh* shadowMesh, bool zfailmethod=true, f32 infinity=10000.0f);
        virtual ~IShadowMesh();


        	//! Sets the mesh from which the shadow volume should be generated.
		/** To optimize shadow rendering, use a simpler mesh for shadows.
		*/
		void setShadowMesh(const IMesh* mesh) ;

		//! Updates the shadow volumes for current light positions.
		 void updateShadowVolumes(core::matrix4 matrix) ;

		//! Set optimization used to create shadow volumes
		/** Default is ESV_SILHOUETTE_BY_POS. If the shadow
		looks bad then give ESV_NONE a try (which will be slower).
		Alternatively you can try to fix the model, it's often
		because it's not closed (aka if you'd put water in it then
		that would leak out). */
		 void setOptimization(ESHADOWVOLUME_OPTIMIZATION optimization) ;

		//! Get currently active optimization used to create shadow volumes
		 ESHADOWVOLUME_OPTIMIZATION getOptimization() const ;

		void render(core::matrix4 matrix);

    protected:

    private:
    	typedef core::array<core::vector3df> SShadowVolume;

		void createShadowVolume(const core::vector3df& pos, bool isDirectional);
		u32 createEdgesAndCaps(const core::vector3df& light, bool isDirectional, SShadowVolume* svp, core::aabbox3d<f32>* bb);
		void renderVolume();

		//! Generates adjacency information based on mesh indices.
		void calculateAdjacency();

		core::aabbox3d<f32> Box;

		// a shadow volume for every light
		core::array<SShadowVolume> ShadowVolumes;

		// a back cap bounding box for every light
		core::array<core::aabbox3d<f32> > ShadowBBox;

		core::array<core::vector3df> Vertices;
		core::array<u16> Indices;
		core::array<u16> Adjacency;
		core::array<u16> Edges;
		// tells if face is front facing
		core::array<bool> FaceData;
		bool AdjacencyDirtyFlag;

		const scene::IMesh* ShadowMesh;

		u32 IndexCount;
		u32 VertexCount;
		u32 ShadowVolumesUsed;

        unsigned int VertexBufferID;

		f32 Infinity;
		bool UseZFailMethod;
		ESHADOWVOLUME_OPTIMIZATION Optimization;
		int midStencilVal;
		GLuint stencil_vbo;
};

}
}

#endif // ISHADOWMESH_H
