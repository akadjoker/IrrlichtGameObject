#ifndef __C_MESHRENDER_H_INCLUDED
#define __C_MESHRENDER_H_INCLUDED

#include "IMeshRender.h"


namespace irr
{
namespace video
{

class CMeshRender : public IMeshRender
{
public:

    CMeshRender();
virtual     ~CMeshRender();
private:

};

} // end namespace video
} // end namespace irr


#endif
