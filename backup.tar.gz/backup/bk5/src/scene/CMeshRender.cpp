
#include "CMeshRender.h"


namespace irr
{
namespace video
{

CMeshRender::CMeshRender()
{

}

CMeshRender::~CMeshRender()
{

}


} // end namespace video
} // end namespace irr



